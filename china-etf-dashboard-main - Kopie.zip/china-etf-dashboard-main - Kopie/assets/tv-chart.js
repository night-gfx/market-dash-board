(function () {
  // Canvas charts (Lightweight Charts, ECharts) render at CSS-size *
  // devicePixelRatio. That ratio follows browser zoom and Windows display
  // scaling (~0.6 at 60% zoom, 1 at 100%, 1.5 at 150% ...), so charts looked
  // soft whenever it was low. Render at least at 3x density
  // regardless of zoom/scaling - the browser then only ever scales the
  // bitmap *down*, which stays crisp. Lightweight Charts 4.1 reads
  // window.devicePixelRatio (allowResizeObserver: false), ECharts gets the
  // same value passed to echarts.init(). Best-effort: falls through silently
  // if the browser doesn't allow redefining the property.
  const MIN_CHART_PIXEL_RATIO = 3;
  try {
    const proto = window.Window && window.Window.prototype;
    const desc = proto && Object.getOwnPropertyDescriptor(proto, "devicePixelRatio");
    if (desc && typeof desc.get === "function" && desc.configurable) {
      const nativeGet = desc.get;
      Object.defineProperty(window, "devicePixelRatio", {
        configurable: true,
        enumerable: desc.enumerable,
        get: function () { return Math.max(MIN_CHART_PIXEL_RATIO, nativeGet.call(window)); },
      });
    }
  } catch (e) { /* not supported here - charts just use the native ratio */ }

  const instances = {};
  const lastStoreRanges = {};
  // Series the user switched off via the legend, per chart div. Lives outside
  // the instance so it survives the rebuilds that zooming/period changes cause.
  const hiddenSeries = {};
  let syncing = false;

  function syncRange(source, range) {
    if (syncing || source.rendering || source.transforming || source.disposed || !range || !source.spec.syncGroup) return;
    syncing = true;
    try {
      Object.values(instances).forEach(function (target) {
        if (target === source || target.rendering || target.disposed ||
            target.spec.syncGroup !== source.spec.syncGroup || target.spec.syncKey !== source.spec.syncKey) return;
        const current = target.chart.timeScale().getVisibleLogicalRange();
        if (!current || Math.abs(current.from - range.from) > 0.001 || Math.abs(current.to - range.to) > 0.001) {
          target.chart.timeScale().setVisibleLogicalRange(range);
        }
      });
    } finally { syncing = false; }
  }

  function timeKey(time) {
    if (typeof time !== "object") return time;
    return `${time.year}-${String(time.month).padStart(2, "0")}-${String(time.day).padStart(2, "0")}`;
  }

  // German short month names as used on axes (März/Mai/Juni/Juli unabbreviated).
  const MONTHS_DE = ["Jan", "Feb", "März", "Apr", "Mai", "Juni", "Juli", "Aug", "Sep", "Okt", "Nov", "Dez"];

  // Any Lightweight Charts time (UTC timestamp, business-day object or
  // "YYYY-MM-DD" string) -> ["YYYY", "MM", "DD"].
  function dateParts(time) {
    const date = typeof time === "number"
      ? new Date(time * 1000).toISOString().slice(0, 10)
      : timeKey(time);
    return String(date).split("-");
  }

  // --- Bold time-axis labels only when two label kinds are on screen -------
  // Lightweight Charts bolds every label of the highest visible weight, so a
  // range showing only years (or only months) came out all bold. We replay its
  // tick selection (TickMarks._buildMarksImpl in v4.1: marks placed by weight,
  // year > month > day, each at least ceil(maxLabelWidth / barSpacing) bars
  // from any already placed mark) and allow bold only when the visible marks
  // mix kinds - then the higher kind (e.g. the year among months) is bold.
  const WEIGHT = { year: 70, month: 60, day: 50 };
  const DAY_TICK_MAX_DAYS = 92;  // day labels are blanked above this span (tickMarkFormatter)

  function tickPoints(spec) {
    const keys = new Set();
    (spec.series || []).forEach(function (s) { (s.data || []).forEach(function (d) { keys.add(timeKey(d.time)); }); });
    const sorted = Array.from(keys).sort();
    return sorted.map(function (key, i) {
      if (i === 0) return WEIGHT.year;
      const prev = sorted[i - 1];
      if (key.slice(0, 4) !== prev.slice(0, 4)) return WEIGHT.year;
      if (key.slice(5, 7) !== prev.slice(5, 7)) return WEIGHT.month;
      return WEIGHT.day;
    });
  }

  function placedMarks(weights, minGap) {
    let placed = [];  // sorted indexes of marks kept so far (higher weights)
    [WEIGHT.year, WEIGHT.month, WEIGHT.day].forEach(function (w) {
      const added = [];
      let pointer = 0, lastLeft = -Infinity;
      for (let i = 0; i < weights.length; i++) {
        if (weights[i] !== w) continue;
        while (pointer < placed.length && placed[pointer] < i) { lastLeft = Math.max(lastLeft, placed[pointer]); pointer++; }
        const right = pointer < placed.length ? placed[pointer] : Infinity;
        if (right - i >= minGap && i - lastLeft >= minGap) { added.push(i); lastLeft = i; }
      }
      placed = placed.concat(added).sort(function (a, b) { return a - b; });
    });
    return placed;
  }

  function updateBoldLabels(inst) {
    if (inst.disposed) return;
    const ts = inst.chart.timeScale();
    const logical = ts.getVisibleLogicalRange();
    const width = ts.width();
    if (!logical || !width || logical.to <= logical.from) return;
    const range = ts.getVisibleRange();
    if (range && range.from !== undefined && range.to !== undefined) {
      inst.visibleDays = (Date.parse(dateParts(range.to).join("-")) -
        Date.parse(dateParts(range.from).join("-"))) / 864e5;
    }
    if (!inst.tickWeights) inst.tickWeights = tickPoints(inst.spec);
    const weights = inst.tickWeights;
    const barSpacing = width / (logical.to - logical.from);
    const maxLabelWidth = (14 + 4) * 5;  // library formula for fontSize 14
    const marks = placedMarks(weights, Math.ceil(maxLabelWidth / barSpacing));
    const from = Math.floor(logical.from), to = Math.ceil(logical.to);
    const kinds = new Set();
    marks.forEach(function (i) {
      if (i < from || i > to) return;
      if (weights[i] === WEIGHT.day && inst.visibleDays > DAY_TICK_MAX_DAYS) return;  // blank label
      kinds.add(weights[i]);
    });
    const bold = kinds.size >= 2;
    if (inst.boldLabels !== bold) {
      inst.boldLabels = bold;
      inst.chart.timeScale().applyOptions({ allowBoldLabels: bold });
    }
  }

  function visibleTransformOf(inst) {
    return inst.spec.visibleTransform || (inst.spec.rebaseVisible ? "indexed" : null);
  }

  function scheduleVisibleTransform(inst) {
    if (!visibleTransformOf(inst) || inst.transforming) return;
    if (inst.transformRAF) return;
    inst.transformRAF = window.requestAnimationFrame(function () {
      inst.transformRAF = null;
      if (inst.disposed || inst.rendering || !inst.container.isConnected) return;
      applyVisibleTransform(inst);
    });
  }

  // Re-bases every series on the first point of the visible range (return /
  // indexed) or recomputes drawdowns from it. `rangeOverride` lets render()
  // apply it synchronously with the requested range, before the chart's first
  // paint - otherwise the raw price levels flash for one frame after every
  // period change.
  function applyVisibleTransform(inst, rangeOverride) {
    const transform = visibleTransformOf(inst);
    if (!transform || inst.transforming || inst.disposed) return;
    const range = rangeOverride || inst.chart.timeScale().getVisibleRange();
    if (!range || range.from === undefined || range.to === undefined) return;
    const from = timeKey(range.from);
    const to = timeKey(range.to);
    inst.transforming = true;
    (inst.spec.series || []).forEach(function (s) {
      const series = inst.series[s.name];
      if (!series) return;
      const data = s.data || [];
      const base = data.find(d => timeKey(d.time) >= from && timeKey(d.time) <= to && Number.isFinite(d.value));
      if (!base || base.value === 0) return;
      const transformKey = `${transform}:${timeKey(base.time)}`;
      if (inst.bases[s.name] === transformKey) return;
      inst.bases[s.name] = transformKey;
      if (transform === "drawdown") {
        let runningMaximum = -Infinity;
        let started = false;
        series.setData(data.map(function (d) {
          if (!Number.isFinite(d.value) || timeKey(d.time) < timeKey(base.time)) {
            return { ...d, value: 0 };
          }
          started = true;
          runningMaximum = Math.max(runningMaximum, d.value);
          return { ...d, value: started && runningMaximum > 0 ? (d.value / runningMaximum - 1) * 100 : 0 };
        }));
      } else if (transform === "return") {
        series.setData(data.map(d => ({ ...d, value: (d.value / base.value - 1) * 100 })));
      } else {
        series.setData(data.map(d => ({ ...d, value: d.value / base.value * 100 })));
      }
    });
    inst.chart.timeScale().setVisibleRange({ from: range.from, to: range.to });
    inst.transforming = false;
    updateValueLabels(inst);
  }

  function reportVisibleRange(inst) {
    if (inst.rendering || inst.ignoreRangeEvents || !inst.spec.rangeStoreId || !window.dash_clientside || !window.dash_clientside.set_props) return;
    const range = inst.chart.timeScale().getVisibleRange();
    if (!range || !range.from || !range.to) return;
    const asDate = function (value) {
      if (typeof value === "string") return value;
      if (typeof value === "number") return new Date(value * 1000).toISOString().slice(0, 10);
      return `${value.year}-${String(value.month).padStart(2, "0")}-${String(value.day).padStart(2, "0")}`;
    };
    let start = asDate(range.from), end = asDate(range.to);
    if (!start || !end || start >= end) return;
    const data = { start: start, end: end };
    if (inst.lastReportedRange && inst.lastReportedRange.start === data.start &&
        inst.lastReportedRange.end === data.end) return;
    const sharedLastRange = lastStoreRanges[inst.spec.rangeStoreId];
    if (sharedLastRange && sharedLastRange.start === data.start && sharedLastRange.end === data.end) return;
    inst.lastReportedRange = data;
    inst.reportedRanges.add(rangeKey(data));
    lastStoreRanges[inst.spec.rangeStoreId] = data;
    window.dash_clientside.set_props(inst.spec.rangeStoreId, { data });
  }

  function rangeKey(range) {
    return range && range.start && range.end ? `${range.start}|${range.end}` : null;
  }

  // Everything that forces a real rebuild - the visible/reset range doesn't.
  function specSignature(spec) {
    return JSON.stringify({
      transform: spec.visibleTransform, rebase: !!spec.rebaseVisible, log: !!spec.logScale,
      left: !!spec.leftAxis, fmt: spec.valueFormat, labels: !!spec.rightValueLabels,
      legend: [spec.showLegend, spec.legendPosition], hlines: spec.hlines || [],
      series: (spec.series || []).map(function (s) {
        const data = s.data || [];
        const first = data[0] || {}, last = data[data.length - 1] || {};
        return [s.name, s.color, s.type, s.dashed, s.lineWidth, data.length,
          timeKey(first.time), first.value, timeKey(last.time), last.value, (s.markers || []).length];
      }),
    });
  }

  function scheduleRangeReport(inst) {
    if (inst.rendering || inst.ignoreRangeEvents || inst.disposed) return;
    if (inst.rangeReportTimer) window.clearTimeout(inst.rangeReportTimer);
    inst.rangeReportTimer = window.setTimeout(function () {
      inst.rangeReportTimer = null;
      reportVisibleRange(inst);
    }, 320);
  }

  function colors() {
    // Charts always render on a solid white plate regardless of the app's
    // dark/light shell theme - keeps every chart's palette/labeling uniform.
    return { bg: "#ffffff", text: "#16181d", muted: "#6b7280", border: "#e3e5ea" };
  }

  function fmtValue(v, fmt) {
    if (v === null || v === undefined || isNaN(v)) return "–";
    if (fmt === "percent") return (v > 0 ? "+" : "") + v.toFixed(2) + " %";
    if (fmt === "pp") return (v >= 0 ? "+" : "") + v.toFixed(2) + " %-Pkt.";
    if (fmt === "ratio") return v.toFixed(2);
    return v.toLocaleString("de-DE", { maximumFractionDigits: 2 });
  }

  function buildLegend(container, position) {
    // Lives in normal flow directly above or below the chart - never an
    // overlay on the plot area - so it never covers the lines and never
    // needs to move out of the way of the data.
    const legend = document.createElement("div");
    legend.className = "tv-legend";
    if (position === "bottom") {
      container.parentNode.insertBefore(legend, container.nextSibling);
    } else {
      container.parentNode.insertBefore(legend, container);
    }
    return legend;
  }

  function buildValueLabels(container) {
    const wrap = document.createElement("div");
    wrap.className = "tv-value-labels";
    container.appendChild(wrap);
    return wrap;
  }

  function updateValueLabels(inst) {
    if (!inst.valueLabels || inst.disposed || !inst.spec.rightValueLabels) return;
    const visibleRange = inst.chart.timeScale().getVisibleRange();
    const visibleToKey = visibleRange && visibleRange.to !== undefined && visibleRange.to !== null
      ? timeKey(visibleRange.to) : null;
    const items = [];
    (inst.spec.series || []).forEach(function (s) {
      const series = inst.series[s.name];
      if (!series || isHidden(inst, s.name)) return;
      const data = series.data();
      if (!data || !data.length) return;
      let last = null;
      for (let i = data.length - 1; i >= 0; i--) {
        const d = data[i];
        if (!Number.isFinite(d.value)) continue;
        if (visibleToKey !== null && timeKey(d.time) > visibleToKey) continue;
        last = d;
        break;
      }
      if (!last) return;
      const y = series.priceToCoordinate(last.value);
      if (y === null || y === undefined) return;
      items.push({ color: s.color, y: y, text: fmtValue(last.value, inst.spec.valueFormat) });
    });
    inst.valueLabels.innerHTML = items.map(function (it) {
      return `<div class="tv-value-label" style="top:${it.y}px;background-color:${it.color}">${it.text}</div>`;
    }).join("");
  }

  function isHidden(inst, name) {
    const hidden = hiddenSeries[inst.container.id];
    return !!hidden && hidden.has(name);
  }

  // Legend entries toggle their series: click hides/shows one line, double
  // click shows only that line (again: all). The last visible line can't be
  // hidden. Hidden series drop out of autoscale and the value labels.
  function applySeriesVisibility(inst) {
    Object.keys(inst.series).forEach(function (name) {
      inst.series[name].applyOptions({ visible: !isHidden(inst, name) });
    });
    inst.legend.querySelectorAll(".tv-legend-row").forEach(function (row) {
      row.classList.toggle("tv-legend-off", isHidden(inst, row.dataset.series));
    });
    updateValueLabels(inst);
  }

  function bindLegendToggle(inst) {
    const names = Object.keys(inst.series);
    if (names.length < 2) return;
    inst.legend.classList.add("tv-legend-interactive");
    const divId = inst.container.id;
    let clickTimer = null;
    inst.legend.querySelectorAll(".tv-legend-row").forEach(function (row) {
      const name = row.dataset.series;
      row.title = "Klick: aus-/einblenden, Doppelklick: nur diese Linie";
      row.addEventListener("click", function () {
        // Wait briefly so a double click doesn't toggle twice first.
        if (clickTimer) return;
        clickTimer = window.setTimeout(function () {
          clickTimer = null;
          const hidden = hiddenSeries[divId] || (hiddenSeries[divId] = new Set());
          if (hidden.has(name)) hidden.delete(name);
          else if (names.filter(function (n) { return !hidden.has(n); }).length > 1) hidden.add(name);
          applySeriesVisibility(inst);
        }, 220);
      });
      row.addEventListener("dblclick", function () {
        if (clickTimer) { window.clearTimeout(clickTimer); clickTimer = null; }
        const hidden = hiddenSeries[divId] || (hiddenSeries[divId] = new Set());
        const onlyThis = hidden.size === names.length - 1 && !hidden.has(name);
        hidden.clear();
        if (!onlyThis) names.forEach(function (n) { if (n !== name) hidden.add(n); });
        applySeriesVisibility(inst);
      });
    });
  }

  const VALUE_LABEL_GUTTER = 72;  // = .tv-value-labels width in custom.css

  function render(divId, spec) {
    const container = document.getElementById(divId);
    if (!container || !window.LightweightCharts) return;
    container._lastSpec = spec;
    // Keep the original spec for redraws; draw with the user's palette.
    if (window.ChartPalette) spec = window.ChartPalette.remap(spec);
    const c = colors();
    const drawdownScale = spec.visibleTransform === "drawdown";
    const useLeftAxis = !!spec.leftAxis;
    const axisWidth = spec.syncGroup ? (container.clientWidth < 520 ? 72 : 100) : 0;
    const labelGutter = spec.rightValueLabels ? VALUE_LABEL_GUTTER : 0;
    const chartWidth = Math.round(Math.max(0, (container.clientWidth || 400) - labelGutter));

    let inst = instances[divId];
    // Zooming reports the visible range to the server (scheduleRangeReport),
    // which answers with a full spec for exactly that range. If the user kept
    // zooming/scrolling while the request was in flight, that answer is
    // already stale - rebuilding from it snapped the chart back to the
    // earlier state. So an echo of a range this chart reported itself never
    // moves the view: same data -> keep the chart as is, otherwise rebuild
    // but at the range currently on screen.
    let reportedRanges = new Set();
    if (inst && !inst.disposed && inst.reportedRanges.has(rangeKey(spec.visibleRange))) {
      reportedRanges = inst.reportedRanges;
      const signature = specSignature(spec);
      if (signature === inst.signature) {
        inst.spec = spec;
        return;
      }
      const live = inst.chart.timeScale().getVisibleRange();
      if (live && live.from !== undefined && live.to !== undefined) {
        spec = Object.assign({}, spec, { visibleRange: {
          start: dateParts(live.from).join("-"), end: dateParts(live.to).join("-"),
        } });
      }
    }
    // A period change can remove dates still referenced by the old visible
    // range. Recreate the chart atomically instead of removing its last series
    // while Lightweight Charts is dispatching time-range events.
    if (inst) {
      inst.disposed = true;
      if (inst.transformRAF) window.cancelAnimationFrame(inst.transformRAF);
      if (inst.rangeReportTimer) window.clearTimeout(inst.rangeReportTimer);
      if (inst.doubleClickHandler) container.removeEventListener("dblclick", inst.doubleClickHandler);
      if (inst.legend) inst.legend.remove();
      inst.observer.disconnect();
      inst.chart.remove();
      delete instances[divId];
      inst = null;
    }
    if (!inst || inst.disposed) {
      container.innerHTML = "";
      const chart = LightweightCharts.createChart(container, {
        width: chartWidth,
        height: Math.round(container.clientHeight || spec.height || 420),
        layout: { background: { type: "solid", color: c.bg }, textColor: c.text, fontFamily: "Arial, sans-serif", fontSize: 14 },
        grid: { vertLines: { visible: false }, horzLines: { visible: false } },
        // entireTextOnly: skip axis values that would only be half visible at
        // the top/bottom edge (e.g. a clipped "+80.00 %") instead of drawing them.
        rightPriceScale: {
          visible: !useLeftAxis,
          borderColor: c.border,
          ticksVisible: true,
          entireTextOnly: true,
          mode: spec.logScale ? 1 : 0,
          minimumWidth: useLeftAxis ? 0 : axisWidth,
          scaleMargins: (!useLeftAxis && drawdownScale) ? { top: 0.06, bottom: 0.08 } : undefined,
        },
        leftPriceScale: {
          visible: useLeftAxis,
          borderColor: c.border,
          ticksVisible: true,
          entireTextOnly: true,
          mode: spec.logScale ? 1 : 0,
          minimumWidth: useLeftAxis ? axisWidth : 0,
          scaleMargins: (useLeftAxis && drawdownScale) ? { top: 0.06, bottom: 0.08 } : undefined,
        },
        timeScale: {
          borderColor: c.border, fixLeftEdge: true, fixRightEdge: true, rightOffset: 2, ticksVisible: true,
          allowBoldLabels: false,  // switched on by updateBoldLabels() when label kinds mix
          // Year ticks "2026", month ticks "März", day ticks "12.03." - the
          // latter only when zoomed in to a few months; on longer ranges the
          // library still drops in the odd day tick where a month label
          // didn't fit, which reads as noise between month names.
          tickMarkFormatter: function (time, tickMarkType) {
            const parts = dateParts(time);
            if (tickMarkType === LightweightCharts.TickMarkType.Year) return parts[0];
            if (tickMarkType === LightweightCharts.TickMarkType.Month) return MONTHS_DE[Number(parts[1]) - 1];
            const current = instances[divId];
            if (current && current.visibleDays > 92) return "";
            return `${parts[2]}.${parts[1]}.`;
          },
        },
        // Crosshair date label on the x axis: "12.03.2026"
        localization: {
          locale: "de-DE",
          timeFormatter: function (time) {
            const parts = dateParts(time);
            return `${parts[2]}.${parts[1]}.${parts[0]}`;
          },
        },
        crosshair: { mode: 0, vertLine: { color: c.muted, width: 1, style: 3, labelBackgroundColor: c.bg }, horzLine: { visible: false, labelVisible: false } },
        handleScroll: { mouseWheel: false, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: false },
        handleScale: { mouseWheel: true, pinch: true, axisPressedMouseMove: false },
      });
      const legend = buildLegend(container, spec.legendPosition);
      container.style.position = "relative";
      const valueLabels = buildValueLabels(container);
      inst = { chart, container, spec, series: {}, bases: {}, legend, valueLabels, disposed: false,
        rendering: true, ignoreRangeEvents: true, transforming: false,
        reportedRanges: reportedRanges, signature: specSignature(spec) };
      instances[divId] = inst;
      chart.timeScale().subscribeVisibleTimeRangeChange(function () {
        updateBoldLabels(inst);  // also refreshes inst.visibleDays for the tick formatter
        if (inst.transforming) return;
        scheduleVisibleTransform(inst);
        scheduleRangeReport(inst);
        updateValueLabels(inst);
      });
      chart.timeScale().subscribeVisibleLogicalRangeChange(function (range) {
        syncRange(inst, range);
        updateBoldLabels(inst);  // zooming changes bar spacing without always changing the time range
      });
      chart.timeScale().subscribeSizeChange(function () { updateBoldLabels(inst); });

      inst.doubleClickHandler = function () {
        if (!inst.spec.resetRange) return;
        inst.chart.timeScale().setVisibleRange({
          from: inst.spec.resetRange.start,
          to: inst.spec.resetRange.end,
        });
        scheduleVisibleTransform(inst);
        scheduleRangeReport(inst);
      };
      container.addEventListener("dblclick", inst.doubleClickHandler);

      inst.observer = new ResizeObserver(function () {
        if (container.clientWidth > 0) {
          const visibleRange = chart.timeScale().getVisibleRange();
          const gutter = inst.spec.rightValueLabels ? VALUE_LABEL_GUTTER : 0;
          chart.resize(Math.round(Math.max(0, container.clientWidth - gutter)), Math.round(container.clientHeight || inst.spec.height || 420));
          if (inst.spec.syncGroup) {
            const w = container.clientWidth < 520 ? 72 : 100;
            const scaleKey = inst.spec.leftAxis ? "leftPriceScale" : "rightPriceScale";
            chart.applyOptions({ [scaleKey]: { minimumWidth: w } });
          }
          if (visibleRange) chart.timeScale().setVisibleRange(visibleRange);
          updateValueLabels(inst);
          updateBoldLabels(inst);
        }
      });
      inst.observer.observe(container);
    } else {
      inst.chart.applyOptions({
        layout: { textColor: c.text },
        rightPriceScale: { borderColor: c.border },
        timeScale: { borderColor: c.border },
      });
    }
    inst.spec = spec;
    inst.rendering = true;
    inst.bases = {};

    // Rebuild series from scratch each render - simplest correct way to
    // handle series being added/removed/re-colored between updates.
    Object.values(inst.series).forEach(function (s) { try { inst.chart.removeSeries(s); } catch (e) {} });
    inst.series = {};

    let legendHtml = "";
    (spec.series || []).forEach(function (s) {
      const seriesOptions = {
        color: s.color,
        lineWidth: s.lineWidth || 2,
        lineStyle: s.dashed ? 2 : 0,
        priceLineVisible: false,
        lastValueVisible: !!s.showLastValue,
        crosshairMarkerRadius: 3,
        priceScaleId: spec.leftAxis ? "left" : "right",
        priceFormat: spec.valueFormat === "percent" || spec.valueFormat === "pp"
          ? { type: "custom", formatter: function (v) { return fmtValue(v, spec.valueFormat); } }
          : { type: "price", precision: 2, minMove: 0.01 },
      };
      let series;
      if (s.type === "area") {
        series = inst.chart.addAreaSeries(Object.assign(seriesOptions, {
          topColor: s.areaTop || s.color + "55",
          bottomColor: s.areaBottom || s.color + "03",
          lineWidth: s.lineWidth || 1.5,
        }));
      } else {
        series = inst.chart.addLineSeries(seriesOptions);
      }
      series.setData(s.data || []);
      if (s.markers && s.markers.length && series.setMarkers) {
        series.setMarkers(s.markers.map(function (m) {
          return {
            time: m.time, position: m.position || "inBar", color: m.color || s.color,
            shape: m.shape || "circle", text: m.text || "",
          };
        }));
      }
      inst.series[s.name] = series;
      const safeName = String(s.name).replace(/"/g, "&quot;");
      legendHtml += `<div class="tv-legend-row" data-series="${safeName}"><span class="tv-dot" style="background:${s.color};border-color:${s.color}"></span>${s.name}</div>`;
    });

    const firstSeries = Object.values(inst.series)[0];
    if (firstSeries) {
      (spec.hlines || []).forEach(function (h) {
        firstSeries.createPriceLine({ price: h.value, color: h.color || c.muted, lineWidth: 1, lineStyle: 3, axisLabelVisible: false, title: h.label || "" });
      });
    }
    inst.defaultLegendHtml = spec.showLegend === false ? "" : legendHtml;
    inst.legend.innerHTML = inst.defaultLegendHtml;
    inst.legend.className = "tv-legend" + (spec.showLegend === false ? " tv-legend-hidden" : "")
      + (spec.legendPosition === "bottom" ? " tv-legend-bottom" : "");
    // Forget hidden names that aren't in this spec any more (e.g. a different
    // selection), then restore the rest.
    const hidden = hiddenSeries[divId];
    if (hidden) {
      hidden.forEach(function (name) { if (!inst.series[name]) hidden.delete(name); });
      if (hidden.size >= Object.keys(inst.series).length) hidden.clear();
    }
    if (spec.showLegend !== false) bindLegendToggle(inst);
    applySeriesVisibility(inst);

    let requestedRange = null;
    if (spec.visibleRange && spec.visibleRange.start && spec.visibleRange.end) {
      requestedRange = { from: spec.visibleRange.start, to: spec.visibleRange.end };
      inst.chart.timeScale().setVisibleRange(requestedRange);
    } else {
      inst.chart.timeScale().fitContent();
    }
    inst.rendering = false;
    window.setTimeout(function () {
      if (!inst.disposed) inst.ignoreRangeEvents = false;
    }, 250);
    // Synchronously, so the first frame already shows the transformed values
    // (setData above loaded raw prices); the scheduled pass is only a fallback
    // for when the range wasn't resolvable yet and is a no-op otherwise.
    applyVisibleTransform(inst, requestedRange);
    scheduleVisibleTransform(inst);
    inst.tickWeights = null;
    updateBoldLabels(inst);
    requestAnimationFrame(function () {
      if (!inst.disposed) syncRange(inst, inst.chart.timeScale().getVisibleLogicalRange());
      if (!inst.disposed) updateValueLabels(inst);
      // Width/bar spacing are only final once the chart has laid out.
      if (!inst.disposed) updateBoldLabels(inst);
    });
  }

  window.renderTVChart = render;

  new MutationObserver(function () {
    Object.keys(instances).forEach(function (id) {
      const inst = instances[id];
      if (!inst.container.isConnected) {
        inst.disposed = true;
        if (inst.transformRAF) window.cancelAnimationFrame(inst.transformRAF);
        if (inst.rangeReportTimer) window.clearTimeout(inst.rangeReportTimer);
        if (inst.doubleClickHandler) inst.container.removeEventListener("dblclick", inst.doubleClickHandler);
        if (inst.legend) inst.legend.remove();
        inst.observer.disconnect();
        inst.chart.remove();
        delete instances[id];
      }
    });
  }).observe(document.documentElement, { childList: true, subtree: true });
})();
