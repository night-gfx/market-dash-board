(function () {
  // "Aktuelles Datum" button at the bottom of end-date calendars. Opt-in via
  // className="date-picker-latest" on a dcc.DatePickerSingle (Dash 4 puts it
  // on the "<id>-wrapper" element; the popup is rendered into the same
  // .dash-datepicker root). Sets today's date - the server snaps it to the
  // last date that actually has prices (pages/overview.py
  // _snap_to_trading_days).
  function todayIso() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  }

  function enhance(content) {
    if (content.querySelector(".date-picker-latest-button")) return;
    const root = content.closest(".dash-datepicker");
    const wrapper = root && root.querySelector(".date-picker-latest[id$='-wrapper']");
    if (!wrapper) return;
    const pickerId = wrapper.id.slice(0, -"-wrapper".length);
    const button = document.createElement("button");
    button.type = "button";
    button.className = "date-picker-latest-button";
    button.textContent = "Aktuelles Datum";
    button.addEventListener("click", function () {
      if (window.dash_clientside && window.dash_clientside.set_props) {
        window.dash_clientside.set_props(pickerId, { date: todayIso() });
      }
      // Close the calendar the same way Escape does (Radix dismissable layer).
      document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    });
    content.appendChild(button);
  }

  new MutationObserver(function () {
    document.querySelectorAll(".dash-datepicker .dash-datepicker-content").forEach(enhance);
  }).observe(document.documentElement, { childList: true, subtree: true });
})();
