(function () {
  // Two-level "Märkte" flyout in the top bar (app.py _asset_flyout):
  // hovering/focusing/clicking an asset class on the left shows its pane on
  // the right - purely client-side, no server round trip. Opening the flyout
  // starts on the class that contains the current page.
  function activate(flyout, key) {
    flyout.querySelectorAll(".nav-flyout-item, .nav-flyout-pane").forEach(function (el) {
      el.classList.toggle("is-active", el.getAttribute("data-key") === key);
    });
  }

  document.addEventListener("mouseover", pick);
  document.addEventListener("focusin", pick);
  document.addEventListener("click", pick);
  function pick(event) {
    const item = event.target.closest && event.target.closest(".nav-flyout-item");
    if (!item) return;
    activate(item.closest(".nav-flyout"), item.getAttribute("data-key"));
  }

  // The dropdown opens by getting class "open" on its .topnav-group (set by
  // the render_open_nav_dropdown callback).
  new MutationObserver(function (mutations) {
    mutations.forEach(function (m) {
      const group = m.target;
      if (!group.classList || !group.classList.contains("topnav-group") || !group.classList.contains("open")) return;
      const flyout = group.querySelector(".nav-flyout");
      // Current page is either a tile in a pane (Aktien sub-pages) or one of
      // the directly linked classes in the list.
      const current = flyout && flyout.querySelector(".nav-link-active");
      const holder = current && (current.closest(".nav-flyout-pane") || current.closest(".nav-flyout-item"));
      if (holder) activate(flyout, holder.getAttribute("data-key"));
    });
  }).observe(document.documentElement, { attributes: true, attributeFilter: ["class"], subtree: true });
})();
