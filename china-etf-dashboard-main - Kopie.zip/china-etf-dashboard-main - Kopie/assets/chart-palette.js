(function () {
  // User-selectable chart palette (settings drawer -> "Diagrammfarben").
  // Charts are built server-side with the default PALETTE (src/theme.py);
  // renderers pass their spec/option through ChartPalette.remap() so every
  // default slot colour is swapped for the same slot of the chosen palette.
  // Colours outside the default slots (status greens/reds, greys) stay as-is.
  //
  // The choice lives in the "settings-chart-palette-store" dcc.Store (local
  // storage); it is read synchronously here so the very first chart paint
  // already uses it instead of flashing the default palette.
  const STORE_KEY = "settings-chart-palette-store";
  let mapping = null;

  function buildMapping(data) {
    if (!data || !Array.isArray(data.base) || !Array.isArray(data.colors)) return null;
    const map = {};
    data.base.forEach(function (hex, i) {
      if (data.colors[i] && hex.toLowerCase() !== data.colors[i].toLowerCase()) {
        map[hex.toLowerCase()] = data.colors[i];
      }
    });
    return Object.keys(map).length ? map : null;
  }

  try {
    const raw = window.localStorage.getItem(STORE_KEY);
    if (raw) mapping = buildMapping(JSON.parse(raw));
  } catch (e) { /* no storage (private window etc.) - default palette */ }

  function remap(obj) {
    if (!mapping || !obj) return obj;
    return JSON.parse(JSON.stringify(obj).replace(/"#([0-9a-fA-F]{6})"/g, function (match, hex) {
      const to = mapping["#" + hex.toLowerCase()];
      return to ? `"${to}"` : match;
    }));
  }

  // Apply a new choice and redraw every chart currently on the page.
  function set(data) {
    const next = buildMapping(data);
    if (JSON.stringify(next) === JSON.stringify(mapping)) return;
    mapping = next;
    document.querySelectorAll("div[id]").forEach(function (el) {
      if (el._lastSpec && el.classList.contains("tv-chart") && window.renderTVChart) {
        window.renderTVChart(el.id, el._lastSpec);
      } else if (el._lastOption && window.renderEChart) {
        window.renderEChart(el.id, el._lastOption);
      }
    });
  }

  window.ChartPalette = { remap: remap, set: set };
})();
