from __future__ import annotations

import json
from urllib.parse import parse_qs

import dash
import dash_ag_grid  # Register table components before the first callback runs.
import dash_mantine_components as dmc
from dash import Dash, Input, Output, State, dcc, html
from dash_iconify import DashIconify

from src.cache import init_cache
from src.theme import (
    ACCENT_OPTIONS, BG, CHART_PALETTES, DEFAULT_CHART_PALETTE, DEFAULT_HEADING_COLOR, DEFAULT_TAX,
    FONT_FAMILY, HEADING_COLOR_OPTIONS, PALETTE, TEXT_MUTED,
)
from pages import asset_allocation, backtesting_home, literature, portfolio, commodities, equities, overview, sp500_sectors
from pages.simple_asset_page import AssetClassPage

dash._dash_renderer._set_react_version("18.2.0")

bonds_page = AssetClassPage(
    "bonds", "Anleihen", "Staats- und Unternehmensanleihen im Überblick.",
    [
        {"label": "US Aggregate Bond", "sub": "AGG", "ticker": "AGG"},
        {"label": "US Treasury 20+Y", "sub": "TLT", "ticker": "TLT"},
        {"label": "US High Yield Corporate", "sub": "HYG", "ticker": "HYG"},
    ],
)
real_estate_page = AssetClassPage(
    "real-estate", "Immobilien", "Börsennotierte Immobilien (REITs), USA und international.",
    [
        {"label": "US Real Estate", "sub": "VNQ", "ticker": "VNQ"},
        {"label": "Internationale Immobilien", "sub": "RWX", "ticker": "RWX"},
    ],
)
hedge_funds_page = AssetClassPage(
    "hedge-funds", "Hedge Fonds", "Liquide Hedge-Fonds-Strategien als ETF-Proxy (Multi-Strategy).",
    [
        {"label": "Multi-Strategy", "sub": "QAI", "ticker": "QAI"},
        {"label": "Managed Futures", "sub": "DBMF", "ticker": "DBMF"},
    ],
)
crypto_page = AssetClassPage(
    "crypto", "Kryptowährungen", "Die größten Kryptowährungen nach Marktkapitalisierung.",
    [
        {"label": "Bitcoin", "sub": "BTC-USD", "ticker": "BTC-USD"},
        {"label": "Ethereum", "sub": "ETH-USD", "ticker": "ETH-USD"},
    ],
)
money_market_page = AssetClassPage(
    "money-market", "Geldmarkt", "Kurzlaufende Anleihen als Cash-Ersatz / risikoarme Verzinsung.",
    [
        {"label": "1-3M US T-Bills", "sub": "BIL", "ticker": "BIL"},
        {"label": "Ultrashort Bond", "sub": "MINT", "ticker": "MINT"},
    ],
)

# Top bar: [home] Märkte ▾ | [home] Backtesting ▾. The Märkte
# dropdown is a two-level flyout (asset classes left, the hovered class's
# pages as tiles right - assets/nav-flyout.js); descriptions and proxies come
# from pages/overview.py ASSET_CLASSES via "key".
NAV_ASSET_CLASSES = [
    # Only classes with sub-categories open a pane of tiles on the right;
    # the others ("path") are plain links to their page.
    {"key": "equities", "label": "Aktien", "icon": "tabler:building-factory-2", "groups": [
        (None, [
            {"label": "Länder", "path": "/laender", "icon": "tabler:world"},
            {"label": "Sektoren", "path": "/sp500-sectors", "icon": "tabler:building-bank"},
        ]),
    ]},
    {"key": "bonds", "label": "Anleihen", "icon": "tabler:certificate", "path": "/anleihen"},
    {"key": "commodities", "label": "Commodities", "icon": "tabler:flask", "path": "/commodities"},
    {"key": "real_estate", "label": "Immobilien", "icon": "tabler:building-estate", "path": "/immobilien"},
    {"key": "hedge_funds", "label": "Hedge Fonds", "icon": "tabler:chart-arrows", "path": "/hedge-fonds"},
    {"key": "crypto", "label": "Krypto", "icon": "tabler:currency-bitcoin", "path": "/krypto"},
    {"key": "cash", "label": "Geldmarkt", "icon": "tabler:cash", "path": "/geldmarkt"},
]

# Keep in sync with pages/backtesting_home.py TOOLS.
NAV_BACKTESTING = [
    {"label": "Asset Allocation", "path": "/asset-allocation", "icon": "tabler:layout-grid-add"},
]

NAV_SECTION_PATHS = {
    "nav-group-assets": ["/"] + [c["path"] for c in NAV_ASSET_CLASSES if "path" in c]
    + [link["path"] for c in NAV_ASSET_CLASSES for _, links in c.get("groups", []) for link in links],
    "nav-group-backtesting": ["/backtesting"] + [link["path"] for link in NAV_BACKTESTING],
    "nav-group-literature": ["/literatur"],
    "nav-group-portfolio": ["/portfolio"],
}

PAGES = {
    "/": overview,
    "/laender": equities,
    "/sp500-sectors": sp500_sectors,
    "/anleihen": bonds_page,
    "/commodities": commodities,
    "/immobilien": real_estate_page,
    "/hedge-fonds": hedge_funds_page,
    "/krypto": crypto_page,
    "/geldmarkt": money_market_page,
    "/asset-allocation": asset_allocation,
    "/backtesting": backtesting_home,
    "/literatur": literature,
    "/portfolio": portfolio,
}

app = Dash(
    __name__,
    external_stylesheets=[
    ],
    external_scripts=[
        "https://cdn.jsdelivr.net/npm/echarts@5.5.1/dist/echarts.min.js",
        "https://cdn.jsdelivr.net/npm/lightweight-charts@4.1.3/dist/lightweight-charts.standalone.production.js",
    ],
    suppress_callback_exceptions=True,
    title="Market Dashboard",
)
init_cache(app)


@app.server.route(literature.FILE_ROUTE + "<path:relpath>")
def literature_file(relpath):
    """Serves a file from the literatur/ folder (pages/literature.py);
    send_from_directory refuses paths outside that folder."""
    from flask import send_from_directory
    return send_from_directory(literature.LIT_DIR, relpath)


def _nav_home(path, label, icon="tabler:home"):
    """Section icon + name as one link to the section's start page
    (Märkte -> market overview, Backtesting -> backtesting start page)."""
    return dcc.Link(
        [DashIconify(icon=icon, width=17, color=TEXT_MUTED, className="nav-icon"),
         html.Span(label, className="nav-section-label")],
        href=path,
        id={"type": "nav-link", "path": path, "role": "home"},
        className="topnav-link nav-section-home",
    )


def _nav_tile(link):
    text = [html.B(link["label"])]
    if link.get("hint"):
        text.append(html.Span(link["hint"], className="nav-tile-hint"))
    return dcc.Link(
        [DashIconify(icon=link["icon"], width=18, className="nav-tile-icon"),
         html.Span(text, className="nav-tile-text")],
        href=link["path"],
        id={"type": "nav-link", "path": link["path"], "role": "tile"},
        className="nav-tile",
    )


def _asset_flyout():
    """Asset classes on the left. Aktien (sub-pages) opens a pane with its
    page tiles on the right on hover; the other classes link straight to
    their page and show no pane (the panes column collapses, custom.css)."""
    items, panes = [], []
    for asset in NAV_ASSET_CLASSES:
        label = [DashIconify(icon=asset["icon"], width=17, className="nav-flyout-icon"), html.Span(asset["label"])]
        if "path" in asset:
            items.append(html.Div(
                dcc.Link(
                    label, href=asset["path"],
                    id={"type": "nav-link", "path": asset["path"], "role": "class"},
                    className="nav-flyout-item-link",
                ),
                className="nav-flyout-item nav-flyout-leaf", **{"data-key": asset["key"]},
            ))
            continue
        items.append(html.Button(
            [*label, DashIconify(icon="tabler:chevron-right", width=13, className="nav-flyout-arrow")],
            type="button", className="nav-flyout-item", **{"data-key": asset["key"]},
        ))
        body = [html.Div([_nav_tile(link) for link in links], className="nav-pane-tiles")
                for _, links in asset["groups"]]
        panes.append(html.Div(body, className="nav-flyout-pane", **{"data-key": asset["key"]}))
    return html.Div(
        [html.Div(items, className="nav-flyout-list"), html.Div(panes, className="nav-flyout-panes")],
        className="topnav-dropdown nav-flyout",
    )


def _backtesting_menu():
    return html.Div(
        [
            html.Div([_nav_tile(link) for link in NAV_BACKTESTING], className="nav-pane-tiles"),
            html.Div("Weitere Tools folgen", className="nav-pane-soon"),
        ],
        className="topnav-dropdown nav-flyout nav-flyout-simple",
    )


def _nav_section(group_id, label, home_path, panel, icon="tabler:home"):
    return html.Div(
        [
            html.Div(
                [
                    _nav_home(home_path, label, icon),
                    html.Button(
                        DashIconify(icon="tabler:chevron-down", width=13, className="topnav-chevron"),
                        id={"type": "nav-group-toggle", "group_id": group_id}, n_clicks=0, type="button",
                        className="topnav-chevron-btn",
                        **{"aria-label": f"{label} Menü öffnen"},
                    ),
                ],
                className="topnav-group-toggle-split nav-section-split",
            ),
            panel,
        ],
        id={"type": "nav-group-wrap", "group_id": group_id},
        className="topnav-group",
    )


def _nav_plain_section(group_id, label, path, icon):
    """A section without sub-pages: just the icon + name link, styled and
    marked like the split buttons (no chevron, no dropdown)."""
    return html.Div(
        html.Div(_nav_home(path, label, icon), className="topnav-group-toggle-split nav-section-split"),
        id={"type": "nav-group-wrap", "group_id": group_id},
        className="topnav-group",
    )


def _nav_items():
    return [
        # No divider line: sections are separated by spacing, the current one
        # is marked by an accent bar along its bottom edge (custom.css).
        _nav_section("nav-group-assets", "Märkte", "/", _asset_flyout(), icon="tabler:chart-line"),
        _nav_section("nav-group-backtesting", "Backtesting", "/backtesting", _backtesting_menu(),
                     icon="tabler:history"),
        _nav_plain_section("nav-group-literature", "Literatur", "/literatur", icon="tabler:books"),
        _nav_plain_section("nav-group-portfolio", "Mein Portfolio", "/portfolio", icon="tabler:briefcase"),
    ]


def _settings_drawer():
    return dmc.Drawer(
        [
            dmc.Stack(
                [
                    dmc.Text("Darstellung", fw=700, size="sm", tt="uppercase", c="dimmed"),
                    dmc.SegmentedControl(
                        id="settings-theme",
                        data=[{"label": "Hell", "value": "light"}],
                        value="light", fullWidth=True,
                        persistence=True, persistence_type="local",
                    ),
                    dmc.Space(h=4),
                    dmc.Text("Akzentfarbe", size="xs", c="dimmed"),
                    dmc.SegmentedControl(
                        id="settings-accent", fullWidth=True,
                        data=[
                            {
                                "label": html.Span(style={
                                    "display": "inline-block", "width": "14px", "height": "14px",
                                    "borderRadius": "50%", "backgroundColor": opt["hex"],
                                }),
                                "value": opt["key"],
                            }
                            for opt in ACCENT_OPTIONS
                        ],
                        value="blue", persistence=True, persistence_type="local",
                    ),
                    dmc.Space(h=4),
                    dmc.Text("Farbe der Überschriftboxen", size="xs", c="dimmed"),
                    html.Div(
                        [
                            html.Button(
                                [html.Span(className="heading-preset-swatch", style={"backgroundColor": opt["hex"]}),
                                 html.Span(opt["label"])],
                                id={"type": "heading-preset", "hex": opt["hex"]},
                                n_clicks=0, type="button", className="heading-preset",
                                title=opt["hex"],
                            )
                            for opt in HEADING_COLOR_OPTIONS
                        ],
                        className="heading-preset-grid",
                    ),
                    dmc.Space(h=4),
                    dmc.Text("Diagrammfarben", size="xs", c="dimmed"),
                    html.Div(
                        [
                            html.Button(
                                [html.Span(opt["label"]),
                                 html.Span([html.Span(style={"backgroundColor": c}) for c in opt["colors"]],
                                           className="chart-preset-swatches")],
                                id={"type": "chart-palette", "key": opt["key"]},
                                n_clicks=0, type="button", className="heading-preset chart-preset",
                            )
                            for opt in CHART_PALETTES
                        ],
                        className="chart-preset-list",
                    ),
                    dmc.Divider(my="sm"),
                    dmc.Text("Steuerparameter (Deutschland)", fw=700, size="sm", tt="uppercase", c="dimmed"),
                    dmc.Text(
                        "Wirkt auf alle Nach-Steuer-Berechnungen im Dashboard.",
                        size="xs", c="dimmed",
                    ),
                    dmc.NumberInput(id="settings-tax-base", label="Kapitalertragsteuer", suffix=" %",
                                    min=0, max=60, step=0.5, value=DEFAULT_TAX["base_rate"],
                                    persistence=True, persistence_type="local"),
                    dmc.NumberInput(id="settings-tax-soli", label="Solidaritätszuschlag (auf Steuer)", suffix=" %",
                                    min=0, max=20, step=0.5, value=DEFAULT_TAX["soli"],
                                    persistence=True, persistence_type="local"),
                    dmc.NumberInput(id="settings-tax-teilfreistellung", label="Teilfreistellung Aktienfonds", suffix=" %",
                                    min=0, max=100, step=1, value=DEFAULT_TAX["teilfreistellung"],
                                    persistence=True, persistence_type="local"),
                    dmc.Text(id="settings-effective-tax", size="xs", c="dimmed"),
                    dmc.Button("Auf Standard zurücksetzen", id="settings-reset", variant="subtle",
                               color="gray", size="xs", mt="sm"),
                ],
                gap="xs",
            ),
        ],
        id="settings-drawer",
        title="Einstellungen",
        position="right",
        size="340px",
        opened=False,
    )


def _cmdk_overlay():
    return html.Div(
        [
            html.Div(className="cmdk-backdrop", id="cmdk-backdrop"),
            html.Div(
                [
                    DashIconify(icon="tabler:search", width=17, className="cmdk-search-icon"),
                    dcc.Input(
                        id="cmdk-input", type="text", autoComplete="off",
                        placeholder="Seiten, Indizes, ETFs, Rohstoffe durchsuchen…",
                        className="cmdk-input",
                    ),
                    html.Kbd("Esc", className="cmdk-esc"),
                ],
                className="cmdk-input-row",
            ),
            html.Div(id="cmdk-results", className="cmdk-results"),
        ],
        id="cmdk-overlay", className="cmdk-overlay",
    )


def build_layout():
    settings_button = html.Button(
        DashIconify(icon="tabler:settings", width=18, color=TEXT_MUTED),
        id="settings-open-btn", n_clicks=0, type="button",
        className="topnav-settings-btn", title="Einstellungen",
        **{"aria-label": "Einstellungen öffnen"},
    )
    header = dmc.AppShellHeader(
        html.Div([*_nav_items(), settings_button], className="topnav-bar"),
        className="app-header",
    )

    return dmc.AppShell(
        [
            header,
            dmc.AppShellMain(html.Div(id="page-content", className="page-content")),
            html.Div(id="topnav-backdrop", className="topnav-backdrop"),
            dcc.Store(id="nav-open-group", data=None),
        ],
        header={"height": 39},
        padding="lg",
        className="app-shell",
        id="app-shell",
    )


app.layout = dmc.MantineProvider(
    [
        dcc.Location(id="url", refresh=False),
        dcc.Store(id="theme-css-sync"),
        dcc.Store(id="settings-heading-store", storage_type="local"),
        dcc.Store(id="settings-chart-palette-store", storage_type="local"),
        dcc.Store(id="tv-chart-sync"),
        dcc.Store(id="recharts-sync"),
        dcc.Store(id="echart-sync"),
        build_layout(),
        _settings_drawer(),
        _cmdk_overlay(),
    ],
    id="mantine-provider",
    theme={
        "fontFamily": FONT_FAMILY,
        "primaryColor": "orange",
        "colors": {
            "dark": [
                "#e6e8ee", "#c7ccd6", "#9aa1b0", "#767e91", "#565f75",
                "#3a4256", "#242b3a", "#171c28", "#12161f", BG,
            ],
        },
    },
    forceColorScheme="light",
)

for module in (
    overview, equities, asset_allocation, sp500_sectors, commodities,
    bonds_page, real_estate_page, hedge_funds_page, crypto_page, money_market_page, literature,
):
    module.register_callbacks(app)


def _parse_search(search):
    if not search:
        return {}
    return {k: v[0] for k, v in parse_qs(search.lstrip("?")).items()}


@app.callback(
    Output("nav-open-group", "data"),
    Input({"type": "nav-group-toggle", "group_id": dash.ALL}, "n_clicks"),
    Input("topnav-backdrop", "n_clicks"),
    Input("url", "pathname"),
    State("nav-open-group", "data"),
    prevent_initial_call=True,
)
def toggle_nav_dropdown(_toggle_clicks, _backdrop_clicks, _pathname, open_group):
    trigger = dash.ctx.triggered_id
    if not isinstance(trigger, dict) or trigger.get("type") != "nav-group-toggle":
        # Clicking the backdrop or navigating to a new page always closes
        # whatever dropdown is open.
        return None
    group_id = trigger["group_id"]
    return None if open_group == group_id else group_id


@app.callback(
    Output({"type": "nav-group-wrap", "group_id": dash.ALL}, "className"),
    Output("topnav-backdrop", "className"),
    Input("nav-open-group", "data"),
    Input("url", "pathname"),
)
def render_open_nav_dropdown(open_group, pathname):
    classes = []
    for item in dash.callback_context.outputs_list[0]:
        group_id = item["id"]["group_id"]
        classes_for_group = ["topnav-group"]
        if (pathname or "/") in NAV_SECTION_PATHS.get(group_id, []):
            classes_for_group.append("topnav-group-active")
        if group_id == open_group:
            classes_for_group.append("open")
        classes.append(" ".join(classes_for_group))
    backdrop_class = "topnav-backdrop open" if open_group else "topnav-backdrop"
    return classes, backdrop_class


@app.callback(Output("page-content", "children"), Input("url", "pathname"), Input("url", "search"))
def render_page(pathname, search):
    module = PAGES.get(pathname, overview)
    return module.layout(_parse_search(search))


@app.callback(
    Output({"type": "nav-link", "path": dash.ALL, "role": dash.ALL}, "className"),
    Input("url", "pathname"),
)
def highlight_active_nav(pathname):
    result = []
    for item in dash.callback_context.outputs_list:
        path, role = item["id"]["path"], item["id"]["role"]
        classes = {"home": "topnav-link nav-section-home", "class": "nav-flyout-item-link"}.get(role, "nav-tile")
        if path == (pathname or "/"):
            classes += " nav-link-active"
        result.append(classes)
    return result


# ---------------------------------------------------------------------------
# TradingView Lightweight Charts: one generic clientside callback renders
# every chart on the page whenever its data Store changes (pattern-matched,
# so individual pages never need to wire their own clientside callback).
# ---------------------------------------------------------------------------

app.clientside_callback(
    """
    function(dataList, idsList) {
        var triggered = dash_clientside.callback_context.triggered || [];
        var renderAll = triggered.length === 0 || triggered.every(function (t) { return t.prop_id === "."; });
        var triggeredIndexes = new Set(triggered.map(function (t) {
            try { return JSON.parse(t.prop_id.slice(0, t.prop_id.lastIndexOf("."))).index; }
            catch (e) { return null; }
        }));
        (dataList || []).forEach(function (data, i) {
            var id = idsList[i];
            if (data && window.renderTVChart && id && (renderAll || triggeredIndexes.has(id.index))) {
                window.renderTVChart(id.index, data);
            }
        });
        return "";
    }
    """,
    Output("tv-chart-sync", "data"),
    Input({"type": "tv-chart-data", "index": dash.ALL}, "data"),
    State({"type": "tv-chart-data", "index": dash.ALL}, "id"),
)

app.clientside_callback(
    """
    function(dataList, idsList) {
        var triggered = dash_clientside.callback_context.triggered || [];
        var renderAll = triggered.length === 0 || triggered.every(function (t) { return t.prop_id === "."; });
        var triggeredIndexes = new Set(triggered.map(function (t) {
            try { return JSON.parse(t.prop_id.slice(0, t.prop_id.lastIndexOf("."))).index; }
            catch (e) { return null; }
        }));
        (dataList || []).forEach(function (data, i) {
            var id = idsList[i];
            if (data && window.renderRecharts && id && (renderAll || triggeredIndexes.has(id.index))) {
                window.renderRecharts(id.index, data);
            }
        });
        return "";
    }
    """,
    Output("recharts-sync", "data"),
    Input({"type": "recharts-data", "index": dash.ALL}, "data"),
    State({"type": "recharts-data", "index": dash.ALL}, "id"),
)

app.clientside_callback(
    """
    function(dataList, idsList) {
        var triggered = dash_clientside.callback_context.triggered || [];
        var renderAll = triggered.length === 0 || triggered.every(function (t) { return t.prop_id === "."; });
        var triggeredIndexes = new Set(triggered.map(function (t) {
            try { return JSON.parse(t.prop_id.slice(0, t.prop_id.lastIndexOf("."))).index; }
            catch (e) { return null; }
        }));
        (dataList || []).forEach(function (data, i) {
            var id = idsList[i];
            if (data && window.renderEChart && id && (renderAll || triggeredIndexes.has(id.index))) {
                window.renderEChart(id.index, data);
            }
        });
        return "";
    }
    """,
    Output("echart-sync", "data"),
    Input({"type": "echart-data", "index": dash.ALL}, "data"),
    State({"type": "echart-data", "index": dash.ALL}, "id"),
)

# ---------------------------------------------------------------------------
# Settings drawer: open/close, theme + accent + tax
# ---------------------------------------------------------------------------

@app.callback(
    Output("settings-drawer", "opened"),
    Input("settings-open-btn", "n_clicks"),
    State("settings-drawer", "opened"),
    prevent_initial_call=True,
)
def toggle_settings(_n, opened):
    return not opened


@app.callback(
    Output("mantine-provider", "forceColorScheme"),
    Input("settings-theme", "value"),
)
def apply_theme(theme):
    return "light"


@app.callback(
    Output("mantine-provider", "theme"),
    Input("settings-accent", "value"),
    State("mantine-provider", "theme"),
)
def apply_accent(accent, theme):
    theme = dict(theme or {})
    theme["primaryColor"] = "blue"
    return theme


app.clientside_callback(
    """
    function(theme, accent) {
        document.documentElement.setAttribute('data-theme', 'light');
        document.documentElement.style.setProperty('--accent', '#5b9bd5');
        return "";
    }
    """,
    Output("theme-css-sync", "data"),
    Input("settings-theme", "value"),
    Input("settings-accent", "value"),
)


# Heading-box colour: a preset tile click writes the colour into a
# local-storage Store (survives reloads); the Store applies it as the
# --heading-bg CSS variable and marks the matching tile.
app.clientside_callback(
    """
    function(clicks) {
        var t = dash_clientside.callback_context.triggered_id;
        if (!t || !(clicks || []).some(function (n) { return n; })) return dash_clientside.no_update;
        return t.hex;
    }
    """,
    Output("settings-heading-store", "data", allow_duplicate=True),
    Input({"type": "heading-preset", "hex": dash.ALL}, "n_clicks"),
    prevent_initial_call=True,
)

app.clientside_callback(
    """
    function(stored, ids) {
        var color = typeof stored === "string" && /^#[0-9a-fA-F]{6}$/.test(stored) ? stored : '%s';
        document.documentElement.style.setProperty('--heading-bg', color);
        return (ids || []).map(function (id) {
            return id.hex.toLowerCase() === color.toLowerCase() ? "heading-preset is-selected" : "heading-preset";
        });
    }
    """ % DEFAULT_HEADING_COLOR,
    Output({"type": "heading-preset", "hex": dash.ALL}, "className"),
    Input("settings-heading-store", "data"),
    State({"type": "heading-preset", "hex": dash.ALL}, "id"),
)


# Chart palette: a tile click stores {key, base, colors} in local storage
# (assets/chart-palette.js reads that same entry on page load, before the
# first chart paint); the Store then re-colours all charts on the page.
_CHART_PALETTE_DATA = {
    opt["key"]: {"key": opt["key"], "base": PALETTE[:8], "colors": opt["colors"]} for opt in CHART_PALETTES
}

app.clientside_callback(
    """
    function(clicks) {
        var palettes = %s;
        var t = dash_clientside.callback_context.triggered_id;
        if (!t || !(clicks || []).some(function (n) { return n; })) return dash_clientside.no_update;
        return palettes[t.key];
    }
    """ % json.dumps(_CHART_PALETTE_DATA),
    Output("settings-chart-palette-store", "data", allow_duplicate=True),
    Input({"type": "chart-palette", "key": dash.ALL}, "n_clicks"),
    prevent_initial_call=True,
)

app.clientside_callback(
    """
    function(stored, ids) {
        var key = stored && stored.key ? stored.key : '%s';
        if (window.ChartPalette) window.ChartPalette.set(stored);
        return (ids || []).map(function (id) {
            return id.key === key ? "heading-preset chart-preset is-selected" : "heading-preset chart-preset";
        });
    }
    """ % DEFAULT_CHART_PALETTE,
    Output({"type": "chart-palette", "key": dash.ALL}, "className"),
    Input("settings-chart-palette-store", "data"),
    State({"type": "chart-palette", "key": dash.ALL}, "id"),
)


@app.callback(
    Output("settings-effective-tax", "children"),
    Input("settings-tax-base", "value"),
    Input("settings-tax-soli", "value"),
    Input("settings-tax-teilfreistellung", "value"),
)
def show_effective_tax(base, soli, teilfreistellung):
    try:
        rate = (base / 100.0) * (1 + soli / 100.0) * (1 - teilfreistellung / 100.0)
        return f"Effektiver Steuersatz auf positive Gewinne: {rate:.2%}"
    except Exception:
        return ""


@app.callback(
    Output("settings-theme", "value"),
    Output("settings-accent", "value"),
    Output("settings-tax-base", "value"),
    Output("settings-tax-soli", "value"),
    Output("settings-tax-teilfreistellung", "value"),
    Output("settings-heading-store", "data"),
    Output("settings-chart-palette-store", "data"),
    Input("settings-reset", "n_clicks"),
    prevent_initial_call=True,
)
def reset_settings(_n):
    return ("light", "blue", DEFAULT_TAX["base_rate"], DEFAULT_TAX["soli"], DEFAULT_TAX["teilfreistellung"],
            DEFAULT_HEADING_COLOR, _CHART_PALETTE_DATA[DEFAULT_CHART_PALETTE])


# Command palette open/close and filtering runs entirely client-side (see
# assets/cmdk.js) so the keyboard shortcut and the sidebar button never fight
# over server round-trips.




if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=8050, threaded=True)
