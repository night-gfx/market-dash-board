from __future__ import annotations

import pandas as pd

# ---------------------------------------------------------------------------
# Color tokens - clean white application theme
# ---------------------------------------------------------------------------
BG = "#ffffff"
SURFACE = "#ffffff"
SURFACE_2 = "#f7f8fa"
BORDER = "#e3e5ea"
TEXT = "#16181d"
TEXT_MUTED = "#6b7280"
ACCENT = "#5b9bd5"
ACCENT_2 = "#8fc1e8"
UP = "#3ecf8e"
DOWN = "#f0616d"

# Charts (TV/ECharts) always render on a fixed white plate regardless of the
# app's dark/light shell theme (see assets/tv-chart.js / echarts-chart.js) -
# these are the matching fixed text tones for anything drawn on that plate.
TEXT_MUTED_LIGHT = "#6b7280"
TEXT_LIGHT = "#16181d"

# Muted "private banking" categorical palette. The first 8 slots are
# validated as an ordered set on white (dataviz validate_palette.js: lightness
# band, chroma, adjacent CVD separation >= 10.6, normal-vision >= 18.2, all
# >= 3:1 contrast) - keep their order, it is what makes neighbours distinct.
# Slots 9-15 are lighter/deeper companions only for pages with more than 8
# series (e.g. the 11 S&P 500 sectors); they are not part of the validated set.
PALETTE = [
    "#2c5fa8",  # navy
    "#b5841c",  # gold
    "#1b998b",  # teal
    "#a23b5b",  # burgundy
    "#5b8fd9",  # steel blue
    "#5f8f3e",  # sage
    "#9457b3",  # plum
    "#d0643c",  # terracotta
    "#7a8699", "#d9b35a", "#6fc3b8", "#d77a93", "#8fbf6a", "#b995d1", "#e8956b",
]

# Chart palettes selectable in the settings drawer ("Diagrammfarben"). Each is
# 8 slots in a validator-checked order (dataviz validate_palette.js, adjacent
# pairs on white; "Harmonie", "Kontrast" and "Hell" have a few sub-3:1 tones,
# acceptable because the charts carry a legend and right-edge value labels).
# Charts are always built with PALETTE; assets/chart-palette.js swaps slot i of
# PALETTE[:8] for slot i of the chosen palette at draw time.
CHART_PALETTES = [
    {"key": "klassisch", "label": "Klassisch", "colors": PALETTE[:8]},
    {"key": "juwel", "label": "Juwel",
     "colors": ["#2953a5", "#007d50", "#764aa2", "#6f8d2a", "#ab2f3f", "#c48225", "#009fad", "#c65d26"]},
    {"key": "harmonie", "label": "Harmonie",
     "colors": ["#2a61b1", "#cc6349", "#3ba5d1", "#b14c79", "#ca932e", "#009589", "#7555a8", "#58994a"]},
    {"key": "kontrast", "label": "Kontrast",
     "colors": ["#175d9b", "#c06240", "#28a0c7", "#884783", "#59985b", "#8679c6", "#c5953b", "#00897d"]},
    {"key": "hell", "label": "Hell",
     "colors": ["#5188cd", "#77b868", "#987aca", "#d9a850", "#cf6e96", "#49bae1", "#de826a", "#35b4a7"]},
]
DEFAULT_CHART_PALETTE = "klassisch"

# Background presets for the section heading boxes, selectable in the
# settings drawer (presets only - no free colour choice).
HEADING_COLOR_OPTIONS = [
    {"label": "Grau", "hex": "#f1f2f5"},
    {"label": "Champagner", "hex": "#f5f1e8"},
    {"label": "Nebelblau", "hex": "#edf1f7"},
    {"label": "Navy-Tint", "hex": "#e6ecf4"},
    {"label": "Greige", "hex": "#f2f0ec"},
    {"label": "Salbei", "hex": "#edf1ee"},
    {"label": "Schiefer", "hex": "#e9ebef"},
    {"label": "Lavendelgrau", "hex": "#eeedf4"},
]
DEFAULT_HEADING_COLOR = "#e6ecf4"

FONT_FAMILY = "Arial, sans-serif"
MONO_FAMILY = FONT_FAMILY

# Fixed accent color shown (read-only) in the settings drawer - selection
# between presets was removed, the app now uses a single accent tone everywhere.
ACCENT_OPTIONS = [
    {"key": "blue", "mantine": "blue", "hex": "#5b9bd5", "label": "Blau"},
]

DEFAULT_TAX = {"base_rate": 25.0, "soli": 5.5, "teilfreistellung": 30.0}


def base_layout(showlegend: bool = False) -> dict:
    return dict(
        showlegend=showlegend,
        hovermode="x unified",
        dragmode="zoom",
        height=460,
        plot_bgcolor="#ffffff",
        paper_bgcolor="#ffffff",
        font=dict(color=TEXT, family=FONT_FAMILY, size=12),
        margin=dict(l=48, r=16, t=16, b=40),
        legend=dict(
            orientation="h", yanchor="top", y=-0.16, x=0,
            bgcolor="rgba(0,0,0,0)", font=dict(color=TEXT_MUTED, size=11),
        ),
        xaxis=dict(showgrid=False, zeroline=False, autorange=True, color=TEXT_MUTED, linecolor=BORDER),
        yaxis=dict(showgrid=True, gridcolor=BORDER, zeroline=False, color=TEXT_MUTED),
        hoverlabel=dict(bgcolor=SURFACE_2, font=dict(color=TEXT, family=FONT_FAMILY)),
    )


HEATMAP_COLORSCALE = [
    [0.0, "#7a2530"], [0.5, "#3a3320"], [1.0, "#1f5c40"],
]


def hex_to_rgb(hex_color: str) -> tuple[int, int, int]:
    hex_color = hex_color.lstrip("#")
    return tuple(int(hex_color[i:i + 2], 16) for i in (0, 2, 4))


def cell_color(value: float, lo: float, hi: float, reverse: bool = False) -> tuple[str, str]:
    if pd.isna(value):
        return SURFACE_2, TEXT_MUTED
    p = 0.5 if hi == lo else (float(value) - lo) / (hi - lo)
    if reverse:
        p = 1.0 - p
    bad, mid, good = (122, 37, 48), (58, 51, 32), (31, 92, 64)
    if p <= 0.5:
        w = p * 2
        a, b = bad, mid
    else:
        w = (p - 0.5) * 2
        a, b = mid, good
    rgb = tuple(round(x + (y - x) * w) for x, y in zip(a, b))
    return f"rgb{rgb}", TEXT


PCT_COLS = {"CAGR p.a.", "Volatilität p.a.", "Max. Drawdown", "Tracking Error p.a.", "Gesamtrendite", "Bestes Jahr", "Schlechtestes Jahr"}
RATIO_COLS = {"Sharpe Ratio", "Sortino", "Calmar", "Information Ratio p.a.", "Sharpe"}


def format_cell(col, value) -> str:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return "–"
    if col in PCT_COLS:
        return f"{value:.2%}"
    if col in RATIO_COLS or str(col).isdigit():
        return f"{value:.2f}"
    if isinstance(value, float):
        return f"{value:.2f}"
    return str(value)


# ---------------------------------------------------------------------------
# Tables - AG Grid (dash-ag-grid). Replaced the old dash_table.DataTable
# (heat_table()) throughout the app: sortable/resizable columns, correct
# numeric sort (values stay numeric; valueFormatter only changes display
# text), and a much more polished institutional look out of the box.
# ---------------------------------------------------------------------------

AG_GRID_DEFAULT_COL_DEF = {"sortable": True, "resizable": True, "filter": False}

AG_GET_ROW_STYLE_FOCUS = {
    "function": "params.data && params.data.__focus "
                "? {fontWeight:'700', borderTop:'2px solid var(--text)', borderBottom:'2px solid var(--text)'} "
                ": null"
}


def _ag_format_kind(col) -> str:
    if col in PCT_COLS:
        return "percent"
    if col in RATIO_COLS or str(col).isdigit():
        return "ratio"
    return "plain"


def ag_value_formatter(kind: str) -> dict:
    if kind == "percent":
        return {"function": "params.value == null ? '–' : (params.value*100).toFixed(2) + ' %'"}
    if kind == "ratio":
        return {"function": "params.value == null ? '–' : params.value.toFixed(2)"}
    return {"function": "params.value == null ? '–' : "
                         "(typeof params.value === 'number' ? params.value.toFixed(2) : params.value)"}


def ag_heat_columns_rows(df: pd.DataFrame, reverse_columns=None, focus_row=None):
    """(columnDefs, rowData) for dash-ag-grid, reproducing the old heat_table()
    per-cell red->green background gradient via a precomputed __bg_/__fg_
    field per row that each column's cellStyle looks up."""
    reverse_columns = set(reverse_columns or [])
    rows = []
    for idx, row in df.iterrows():
        rec = {"__index__": str(idx), "__focus": bool(focus_row is not None and idx == focus_row)}
        for c in df.columns:
            v = row[c]
            rec[str(c)] = None if (v is None or (isinstance(v, float) and pd.isna(v))) else float(v)
        rows.append(rec)

    for c in df.columns:
        vals = pd.to_numeric(df[c], errors="coerce").dropna()
        if vals.empty:
            continue
        lo, hi = float(vals.min()), float(vals.max())
        rev = c in reverse_columns
        for pos, v in enumerate(df[c]):
            if pd.isna(v):
                continue
            bg, fg = cell_color(float(v), lo, hi, rev)
            rows[pos][f"__bg_{c}"] = bg
            rows[pos][f"__fg_{c}"] = fg

    column_defs = [{
        "field": "__index__", "headerName": "", "pinned": "left", "minWidth": 150,
        "cellStyle": {"fontWeight": "600"},
    }]
    for c in df.columns:
        field = str(c)
        column_defs.append({
            # field names routinely contain "." (e.g. "CAGR p.a.") which AG
            # Grid's default field resolver treats as a nested-object path -
            # an explicit valueGetter (plain bracket lookup) sidesteps that.
            "field": field, "headerName": field,
            "valueGetter": {"function": f"params.data['{field}']"},
            "valueFormatter": ag_value_formatter(_ag_format_kind(c)),
            "cellStyle": {"function": f"params.data['__bg_{field}'] "
                                       f"? {{backgroundColor: params.data['__bg_{field}'], color: params.data['__fg_{field}']}} "
                                       f": null"},
        })
    return column_defs, rows


def ag_heat_table(df: pd.DataFrame, reverse_columns=None, focus_row=None, id_=None, height=None):
    import dash_ag_grid as dag
    column_defs, rows = ag_heat_columns_rows(df, reverse_columns, focus_row)
    kwargs = {"id": id_} if id_ else {}
    style = {"width": "100%", "height": f"{height}px"} if height else {"width": "100%"}
    return dag.AgGrid(
        columnDefs=column_defs, rowData=rows,
        className="ag-theme-quartz app-ag-grid",
        style=style,
        defaultColDef=AG_GRID_DEFAULT_COL_DEF,
        dashGridOptions={
            "domLayout": "normal" if height else "autoHeight",
            "animateRows": False, "suppressCellFocus": True,
            "autoSizeStrategy": {"type": "fitCellContents"},
            "getRowStyle": AG_GET_ROW_STYLE_FOCUS,
        },
        **kwargs,
    )


def ag_heat_table_placeholder(id_):
    """Empty AG Grid shell for a table that's populated later via
    Output(id, "columnDefs") / Output(id, "rowData") from a callback -
    mirrors ag_heat_table()'s styling/options so there's no visual jump."""
    import dash_ag_grid as dag
    return dag.AgGrid(
        id=id_, columnDefs=[], rowData=[],
        className="ag-theme-quartz app-ag-grid",
        style={"width": "100%"},
        defaultColDef=AG_GRID_DEFAULT_COL_DEF,
        dashGridOptions={
            "domLayout": "autoHeight", "animateRows": False,
            "suppressCellFocus": True, "autoSizeStrategy": {"type": "fitCellContents"},
            "getRowStyle": AG_GET_ROW_STYLE_FOCUS,
        },
    )


def ag_table(df: pd.DataFrame, formats: dict | None = None, id_=None, height=None, page_size=None, get_row_style=None):
    """Plain (non-heat) AG Grid table built from a DataFrame. `formats` maps
    column name -> 'percent'/'ratio' for display formatting while the
    underlying cell value stays numeric (so sorting is correct, unlike the
    old DataTable which stored pre-formatted strings)."""
    import dash_ag_grid as dag
    formats = formats or {}
    rows = []
    for _, row in df.iterrows():
        rec = {}
        for c in df.columns:
            v = row[c]
            if isinstance(v, float) and pd.isna(v):
                rec[str(c)] = None
            elif c in formats and isinstance(v, (int, float)):
                rec[str(c)] = float(v)
            else:
                rec[str(c)] = v
        rows.append(rec)

    column_defs = []
    for c in df.columns:
        field = str(c)
        # See ag_heat_columns_rows(): dots in the field name would otherwise
        # be read as a nested-object path by AG Grid's default resolver.
        col = {"field": field, "headerName": field, "valueGetter": {"function": f"params.data['{field}']"}}
        if c in formats:
            col["valueFormatter"] = ag_value_formatter(formats[c])
        column_defs.append(col)

    kwargs = {"id": id_} if id_ else {}
    style = {"width": "100%", "height": f"{height}px"} if height else {"width": "100%"}
    grid_options = {"domLayout": "normal" if (height or page_size) else "autoHeight",
                     "animateRows": False, "suppressCellFocus": True,
                     "autoSizeStrategy": {"type": "fitCellContents"}}
    if page_size:
        grid_options.update({"pagination": True, "paginationPageSize": page_size})
    if get_row_style:
        grid_options["getRowStyle"] = get_row_style
    return dag.AgGrid(
        columnDefs=column_defs, rowData=rows,
        className="ag-theme-quartz app-ag-grid",
        style=style,
        defaultColDef=AG_GRID_DEFAULT_COL_DEF,
        dashGridOptions=grid_options,
        **kwargs,
    )


TABLE_STYLE_CELL = dict(
    backgroundColor="var(--surface)", color="var(--text)", border="1px solid var(--border)",
    fontFamily=FONT_FAMILY, fontSize="12.5px", padding="6px 10px",
)
TABLE_STYLE_HEADER = dict(
    backgroundColor="var(--surface-2)", color="var(--text-muted)", border="1px solid var(--border)",
    fontFamily=FONT_FAMILY, fontSize="11px", fontWeight="700",
    textTransform="uppercase", letterSpacing="0.04em",
)
TABLE_STYLE_DATA_CONDITIONAL_STRIPE = [
    {"if": {"row_index": "odd"}, "backgroundColor": "var(--surface-2)"},
]

GRAPH_CONFIG = {"displaylogo": False, "scrollZoom": True, "displayModeBar": False, "doubleClick": "reset"}


def empty_figure():
    import plotly.graph_objects as go
    fig = go.Figure()
    fig.update_layout(**base_layout(False))
    return fig


# ---------------------------------------------------------------------------
# TradingView Lightweight Charts - JSON spec builders.
# The heavy lifting (rendering, theming, crosshair legend) lives client-side
# in assets/tv-chart.js; these helpers just shape pandas data into the spec
# it expects and wrap it in the Div+Store pair the generic clientside
# callback in app.py picks up (pattern-matched by id={"type":"tv-chart-data"}).
# ---------------------------------------------------------------------------

def tv_series(name, series: pd.Series, color: str, dashed: bool = False, area: bool = False,
              show_last_value: bool = True, line_width: float = None, markers: list = None):
    s = pd.to_numeric(series, errors="coerce").dropna()
    data = [{"time": idx.strftime("%Y-%m-%d"), "value": float(v)} for idx, v in s.items()]
    spec = {
        "name": name, "color": color, "data": data,
        "type": "area" if area else "line",
        "dashed": dashed, "showLastValue": show_last_value,
    }
    if line_width is not None:
        spec["lineWidth"] = line_width
    if markers:
        spec["markers"] = markers
    return spec


def tv_marker(time, text="", color=TEXT_MUTED_LIGHT, position="inBar", shape="circle"):
    return {"time": time.strftime("%Y-%m-%d") if hasattr(time, "strftime") else time,
            "text": text, "color": color, "position": position, "shape": shape}


def tv_spec(series_list, height: int = 420, log_scale: bool = False, value_format: str = "plain",
            show_legend: bool = True, legend_position: str = "top", hlines=None, rebase_visible: bool = False):
    return {
        "series": series_list, "height": height, "logScale": log_scale,
        "valueFormat": value_format, "showLegend": show_legend,
        "legendPosition": legend_position, "hlines": hlines or [],
        "rebaseVisible": rebase_visible,
    }


def card_header(title: str, controls=None):
    """Section-card title row; when `controls` is given (e.g. a 1J/3J/Max
    range SegmentedControl) it's right-aligned on the same row as the title
    instead of stacked above the chart."""
    from dash import html
    if controls is None:
        return html.Div(title, className="section-title")
    return html.Div(
        [html.Div(title, className="section-title"), html.Div(controls)],
        className="section-card-header",
    )


def tv_chart(chart_id: str, spec: dict):
    """A TradingView Lightweight Charts container + its data Store. Import
    dash locally to keep this module import-light for non-Dash callers."""
    from dash import dcc, html
    return html.Div([
        html.Div(
            id=chart_id,
            className="tv-chart",
            style={"height": f"{spec.get('height', 420)}px"},
            role="group",
            tabIndex=0,
            **{"aria-label": spec.get("ariaLabel", "Interaktives Zeitreihendiagramm")},
        ),
        dcc.Store(id={"type": "tv-chart-data", "index": chart_id}, data=spec),
    ])


# ---------------------------------------------------------------------------
# Recharts - browser-rendered SVG charts for React-owned Dash surfaces.
# The renderer lives in assets/overview-recharts.js; these helpers only shape
# pandas data and provide the Div+Store contract consumed by app.py.
# ---------------------------------------------------------------------------

def recharts_series(name, series: pd.Series, color: str, line_width: float = 2.0):
    s = pd.to_numeric(series, errors="coerce").dropna()
    # Full timestamp (not just the date) - callers may feed intraday data
    # with several points per calendar day, and a date-only key would
    # collapse them into one row on the JS side (assets/overview-recharts.js
    # keys its combined rows by this "time" string).
    return {
        "name": name,
        "color": color,
        "lineWidth": line_width,
        "data": [{"time": idx.strftime("%Y-%m-%d %H:%M:%S"), "value": float(value)}
                 for idx, value in s.items()],
    }


def recharts_spec(series_list, height: int = 420, log_scale: bool = False,
                  value_format: str = "plain", show_legend: bool = True,
                  sync_id: str = None, sparkline: bool = False):
    return {
        "series": series_list,
        "height": height,
        "logScale": log_scale,
        "valueFormat": value_format,
        "showLegend": show_legend,
        "syncId": sync_id,
        "sparkline": sparkline,
    }


def recharts_chart(chart_id: str, spec: dict, class_name: str = "recharts-chart"):
    from dash import dcc, html
    return html.Div([
        html.Div(
            id=chart_id,
            className=class_name,
            style={"height": f"{spec.get('height', 420)}px", "width": "100%"},
            **{"aria-label": spec.get("ariaLabel", "Interaktives Zeitreihendiagramm")},
        ),
        dcc.Store(id={"type": "recharts-data", "index": chart_id}, data=spec),
    ])


def recharts_sparkline(chart_id: str, series: pd.Series, color: str, height: int = 44,
                        reference_value: float = None, session: tuple = None,
                        segments: list = None, mid_ticks: list = None, venues: list = None):
    """`reference_value` (typically the previous trading day's close) draws a
    dashed baseline plus a green/red fill between it and the intraday line,
    the familiar "vs. previous close" stock-ticker look. `session` is an
    optional (open, close, open_label, close_label) tuple of naive timestamps:
    the x axis then spans the whole trading session with open/close ticks, so
    a partial day shows how far into the session the data reaches.
    `segments` [(start, end, color)] colour parts of the x axis (e.g. one
    colour per trading venue), `mid_ticks` [(timestamp, label)] add ticks
    between open and close (e.g. the hand-over from London to New York),
    `venues` [(start, end, label, color)] print a venue abbreviation (NY,
    LDN, ...) centred under its axis segment."""
    spec = recharts_spec(
        [recharts_series("Kurs", series, color, line_width=1.7)],
        height=height,
        show_legend=False,
        sparkline=True,
    )
    spec["ariaLabel"] = "Intraday-Kursverlauf"
    if reference_value is not None:
        spec["referenceValue"] = float(reference_value)
    if session is not None:
        open_ts, close_ts, open_label, close_label = session
        # Naive timestamps as epoch ms "as if UTC" - the JS side parses the
        # row times the same way, so only the relative positions matter.
        open_ms, close_ms = open_ts.value // 10**6, close_ts.value // 10**6
        ticks = [(open_ms, open_label), (close_ms, close_label)]
        ticks += [(ts.value // 10**6, label) for ts, label in (mid_ticks or [])]
        spec["xTicks"] = [{"value": v, "label": label} for v, label in sorted(ticks)]
        if segments:
            spec["xSegments"] = [{"from": a.value // 10**6, "to": b.value // 10**6, "color": c}
                                 for a, b, c in segments]
        if venues:
            spec["xVenues"] = [{"from": a.value // 10**6, "to": b.value // 10**6, "label": label, "color": c}
                               for a, b, label, c in venues]
        s = series.dropna()
        if not s.empty:
            open_ms = min(open_ms, s.index[0].value // 10**6)
            close_ms = max(close_ms, s.index[-1].value // 10**6)
        spec["xDomain"] = [open_ms, close_ms]
    return recharts_chart(chart_id, spec, class_name="recharts-sparkline")


# ---------------------------------------------------------------------------
# ECharts - for chart types Lightweight Charts can't do (heatmaps, scatter,
# gradient stacked areas, the world map). Same Div+Store+pattern-matching-
# callback wiring as tv_chart(); rendering lives in assets/echarts-chart.js
# (generic) / assets/echarts-map.js (world map, has its own geo bootstrap).
# ---------------------------------------------------------------------------

def echart(chart_id: str, option: dict, height: int = 420):
    from dash import dcc, html
    return html.Div([
        html.Div(id=chart_id, style={"height": f"{height}px", "width": "100%"}),
        dcc.Store(id={"type": "echart-data", "index": chart_id}, data=option),
    ])


def sparkline_figure(series: pd.Series, color: str = None, height: int = 44) -> dict:
    """Tiny axis-less line chart for inline use in cards/rows."""
    import plotly.graph_objects as go
    s = series.dropna()
    color = color or ACCENT
    fig = go.Figure(go.Scatter(
        x=list(range(len(s))), y=s.values, mode="lines",
        line=dict(width=1.6, color=color), hoverinfo="skip",
    ))
    if len(s) >= 2:
        fig.add_trace(go.Scatter(
            x=[len(s) - 1], y=[s.values[-1]], mode="markers",
            marker=dict(size=4, color=color), hoverinfo="skip",
        ))
    fig.update_layout(
        height=height, margin=dict(l=0, r=0, t=2, b=2),
        font=dict(family=FONT_FAMILY),
        plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)",
        showlegend=False,
        xaxis=dict(visible=False), yaxis=dict(visible=False),
    )
    return fig
