"""Literature database: every file below literatur/ (next to app.py), grouped
by topic = its sub-folder. The folder is re-scanned on every page view and
search, so dropped-in files show up without a restart. Files are served by
the /literatur/datei/<path> route in app.py (opens in a new tab)."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from urllib.parse import quote

import dash_mantine_components as dmc
from dash import Input, Output, dcc, html
from dash_iconify import DashIconify

from src.theme import card_header

LIT_DIR = Path(__file__).resolve().parents[1] / "literatur"
FILE_ROUTE = "/literatur/datei/"
NO_TOPIC = "Ohne Thema"

TYPE_ICONS = {
    ".pdf": ("tabler:file-type-pdf", "PDF"),
    ".doc": ("tabler:file-type-doc", "Word"), ".docx": ("tabler:file-type-docx", "Word"),
    ".xls": ("tabler:file-type-xls", "Excel"), ".xlsx": ("tabler:file-spreadsheet", "Excel"),
    ".csv": ("tabler:file-type-csv", "CSV"),
    ".ppt": ("tabler:file-type-ppt", "PowerPoint"), ".pptx": ("tabler:presentation", "PowerPoint"),
    ".txt": ("tabler:file-text", "Text"), ".md": ("tabler:markdown", "Markdown"),
    ".html": ("tabler:file-type-html", "HTML"), ".htm": ("tabler:file-type-html", "HTML"),
    ".png": ("tabler:photo", "Bild"), ".jpg": ("tabler:photo", "Bild"), ".jpeg": ("tabler:photo", "Bild"),
}


def _size(num_bytes: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if num_bytes < 1024 or unit == "GB":
            text = f"{num_bytes:.0f} {unit}" if unit == "B" else f"{num_bytes:.1f} {unit}"
            return text.replace(".", ",")
        num_bytes /= 1024
    return ""


def scan(query: str = "") -> dict[str, list[dict]]:
    """{topic: [file info, ...]} - topics sorted, NO_TOPIC last; files by name."""
    LIT_DIR.mkdir(exist_ok=True)
    terms = [t for t in (query or "").lower().split() if t]
    topics: dict[str, list[dict]] = {}
    for path in LIT_DIR.rglob("*"):
        rel = path.relative_to(LIT_DIR)
        if not path.is_file() or any(part.startswith((".", "~$")) for part in rel.parts):
            continue
        topic = " / ".join(rel.parts[:-1]) or NO_TOPIC
        haystack = f"{topic} {path.stem}".lower()
        if terms and not all(t in haystack for t in terms):
            continue
        stat = path.stat()
        icon, kind = TYPE_ICONS.get(path.suffix.lower(), ("tabler:file", path.suffix.lstrip(".").upper() or "Datei"))
        topics.setdefault(topic, []).append({
            "name": path.stem, "icon": icon, "kind": kind, "size": _size(stat.st_size),
            "modified": datetime.fromtimestamp(stat.st_mtime).strftime("%d.%m.%Y"),
            "href": FILE_ROUTE + quote(rel.as_posix()),
        })
    order = sorted(topics, key=lambda t: (t == NO_TOPIC, t.lower()))
    return {t: sorted(topics[t], key=lambda f: f["name"].lower()) for t in order}


def _row(f):
    return html.A([
        DashIconify(icon=f["icon"], width=20, className="literature-icon"),
        html.Span(f["name"], className="literature-name"),
        html.Span(f["kind"], className="literature-meta"),
        html.Span(f["size"], className="literature-meta literature-size"),
        html.Span(f["modified"], className="literature-meta"),
    ], href=f["href"], target="_blank", rel="noopener", className="literature-row")


def render(query: str = ""):
    topics = scan(query)
    if not topics:
        text = (f"Keine Treffer für „{query}“." if query else
                f"Noch keine Literatur abgelegt. Dateien in den Ordner {LIT_DIR} legen, "
                "Unterordner werden zu Themen.")
        return html.Div(dmc.Text(text, className="literature-empty"), className="section-card")
    cards = []
    for topic, files in topics.items():
        cards.append(html.Div([
            html.Div([
                card_header(topic, html.Div()),
                dmc.Text(f"{len(files)} Dokument" + ("" if len(files) == 1 else "e"),
                         className="overview-section-subtitle", size="xs", c="dimmed"),
            ], className="overview-heading-box"),
            html.Div([_row(f) for f in files], className="literature-list"),
        ], className="section-card"))
    return cards


def layout(params=None):
    return html.Div([
        html.Div([
            html.Div([
                card_header("Literatur", html.Div()),
                dmc.Text("Dokumente aus dem Ordner literatur (Unterordner = Themen)",
                         className="overview-section-subtitle", size="xs", c="dimmed"),
            ], className="overview-heading-box"),
            html.Div([
                DashIconify(icon="tabler:search", width=15, className="literature-search-icon"),
                dcc.Input(id="literature-search", type="text", debounce=0.3, placeholder="Titel oder Thema suchen",
                          className="literature-search", autoComplete="off"),
            ], className="overview-controls literature-controls"),
        ], className="section-card literature-intro"),
        html.Div(render(), id="literature-results", className="literature-results"),
    ], className="markets-overview")


def register_callbacks(app):
    @app.callback(Output("literature-results", "children"), Input("literature-search", "value"),
                  prevent_initial_call=True)
    def search(query):
        return render(query or "")
