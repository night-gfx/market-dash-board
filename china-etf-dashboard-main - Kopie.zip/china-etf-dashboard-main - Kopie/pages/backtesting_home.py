"""Backtesting start page (house icon next to "Backtesting" in the top bar):
one card per backtesting tool, built from the same card/heading-box styles
as the market overview."""
from __future__ import annotations

import dash_mantine_components as dmc
from dash import dcc, html
from dash_iconify import DashIconify

from src.theme import card_header

# Keep in sync with NAV_BACKTESTING in app.py.
TOOLS = [
    {
        "label": "Asset Allocation", "path": "/asset-allocation", "icon": "tabler:layout-grid-add",
        "description": "Portfolios zusammenstellen und rückwirkend testen",
    },
]


def _tool_card(tool):
    return dcc.Link(
        html.Div([
            html.Div([
                html.Div([
                    DashIconify(icon=tool["icon"], width=20, className="backtesting-tool-icon"),
                    html.Span(tool["label"], className="section-title"),
                ], className="backtesting-tool-title"),
                dmc.Text(tool["description"], className="overview-section-subtitle", size="xs", c="dimmed"),
            ], className="overview-heading-box"),
            html.Div([
                html.Span("Öffnen"),
                DashIconify(icon="tabler:arrow-right", width=14),
            ], className="backtesting-tool-open"),
        ], className="section-card backtesting-tool-card"),
        href=tool["path"], className="backtesting-tool-link",
    )


def layout(params=None):
    return html.Div([
        html.Div([
            html.Div([
                card_header("Backtesting", html.Div()),
                dmc.Text("Werkzeuge zum Testen von Portfolios und Strategien",
                         className="overview-section-subtitle", size="xs", c="dimmed"),
            ], className="overview-heading-box"),
        ], className="section-card backtesting-intro"),
        html.Div([_tool_card(t) for t in TOOLS], className="backtesting-tools"),
    ], className="markets-overview")
