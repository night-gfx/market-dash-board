from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import math

import dash_mantine_components as dmc
import pandas as pd
from dash import Input, Output, State, ctx, dcc, html, no_update
from dash.exceptions import PreventUpdate
from dash_iconify import DashIconify

from src.cache import INTRADAY_TTL, LONG_TTL, cache
from src.data import download_adjusted_close, download_intraday_close
from src.metrics import cagr, max_drawdown
from src.theme import (
    PALETTE,
    ag_heat_table, ag_value_formatter, card_header,
    recharts_sparkline,
    tv_chart, tv_series, tv_spec,
)

LOCAL_TZ = "Europe/Berlin"

# Regular trading session per exchange, in the exchange's own time zone.
# Converted to LOCAL_TZ per day, so DST differences between the US and
# Europe are handled automatically. None = trades around the clock.
US_SESSION = ("America/New_York", "09:30", "16:00")

# venues: listings of the SAME index in time order [(venue, ticker, fx)] -
# chained into one trading day on the overview sparklines (_chained_intraday).
ASSET_CLASSES = [
    {"key": "equities", "label": "Aktien", "description": "Globale Aktienmärkte vergleichen und Entwicklungen einordnen.", "sub": "MSCI ACWI", "ticker": "ACWI", "venues": [("TYO", "2559.T", "JPY=X"), ("LDN", "ISAC.L", None), ("NY", "ACWI", None)], "icon": "tabler:chart-line", "session": US_SESSION},
    {"key": "bonds", "label": "Anleihen", "description": "Staats- und Unternehmensanleihen vergleichen und Zinsmärkte analysieren.", "sub": "US Aggregate Bond", "ticker": "AGG", "venues": [("LDN", "IUAG.L", None), ("NY", "AGG", None)], "icon": "tabler:certificate", "session": US_SESSION},
    {"key": "commodities", "label": "Commodities", "description": "Rohstoffmärkte und ihre langfristige Entwicklung untersuchen.", "sub": "DB Commodity Index", "ticker": "DBC", "icon": "tabler:flask", "session": US_SESSION},
    {"key": "real_estate", "label": "Immobilien", "description": "Globale Immobilienmärkte und börsennotierte REITs vergleichen.", "sub": "US Real Estate", "ticker": "VNQ", "icon": "tabler:building-estate", "session": US_SESSION},
    {"key": "hedge_funds", "label": "Hedge Fonds", "description": "Alternative Strategien und ihre Wertentwicklung vergleichen.", "sub": "Multi-Strategy (QAI)", "ticker": "QAI", "icon": "tabler:chart-arrows", "session": US_SESSION},
    {"key": "crypto", "label": "Krypto", "description": "Digitale Vermögenswerte und ihre Marktentwicklung verfolgen.", "sub": "Bitcoin", "ticker": "BTC-USD", "icon": "tabler:currency-bitcoin", "session": None},
    {"key": "cash", "label": "Geldmarkt", "description": "Kurzfristige Zinsen und risikoarme Geldmarktanlagen vergleichen.", "sub": "1-3M T-Bills", "ticker": "BIL", "icon": "tabler:cash", "session": US_SESSION},
]

RANGE_OPTIONS = [
    {"label": html.Span("1W", className="overview-range-option overview-range-1w"), "value": "1w"},
    {"label": html.Span("1M", className="overview-range-option overview-range-1m"), "value": "1m"},
    {"label": html.Span("6M", className="overview-range-option overview-range-6m"), "value": "6m"},
    {"label": html.Span("1J", className="overview-range-option overview-range-1"), "value": "1"},
    {"label": html.Span("3J", className="overview-range-option overview-range-3"), "value": "3"},
    {"label": html.Span("5J", className="overview-range-option overview-range-5"), "value": "5"},
    {"label": html.Span("10J", className="overview-range-option overview-range-10"), "value": "10"},
    {"label": html.Span("Max", className="overview-range-option overview-range-max"), "value": "max"},
]


@cache.memoize(timeout=LONG_TTL, response_filter=lambda result: not result.empty)
def _asset_class_series(ticker: str) -> pd.Series:
    try:
        return download_adjusted_close(ticker, start="2000-01-01")
    except Exception:
        return pd.Series(dtype=float)


def _session_bounds(item, day: pd.Timestamp):
    """(open, close, open_label, close_label) of `item`'s session on `day`,
    as naive LOCAL_TZ timestamps."""
    session = item.get("session")
    if session is None:
        return day, day + pd.Timedelta(days=1), "00:00", "24:00"
    tz, open_time, close_time = session
    open_ts, close_ts = (
        pd.Timestamp(f"{day.date()} {t}", tz=tz).tz_convert(LOCAL_TZ).tz_localize(None)
        for t in (open_time, close_time)
    )
    return open_ts, close_ts, open_ts.strftime("%H:%M"), close_ts.strftime("%H:%M")


@cache.memoize(timeout=INTRADAY_TTL, response_filter=lambda result: not result.empty)
def _intraday_series(ticker: str) -> pd.Series:
    """Today's ~15min intraday prices in LOCAL_TZ (free via Yahoo, ~15min
    delayed). Switches to today as soon as the session has its first bar
    (15:30 for US listings) - waiting for two bars kept showing the previous
    day for the first 15+ minutes. Falls back to the most recent trading day
    in the window before the open / on days without trading."""
    try:
        s = download_intraday_close(ticker, period="5d", interval="15m", tz=LOCAL_TZ)
        if s.empty:
            return s
        days = s.index.normalize()
        today = pd.Timestamp.now(tz=LOCAL_TZ).tz_localize(None).normalize()
        today_part = s[days == today]
        if len(today_part) >= 1:
            return today_part
        return s[days == days[days < today].max()] if (days < today).any() else today_part
    except Exception:
        return pd.Series(dtype=float)


# Trading venues for the overview sparklines: regular session in the
# venue's own time zone (converted per day, so every DST constellation is
# exact) and axis colour. Tokyo trades 09:00-15:30 JST since Nov 2024.
VENUES = {
    "TYO": {"session": ("Asia/Tokyo", "09:00", "15:30"), "color": PALETTE[6]},
    "LDN": {"session": ("Europe/London", "08:00", "16:30"), "color": PALETTE[1]},
    "NY": {"session": US_SESSION, "color": PALETTE[0]},
}
NO_TRADING_COLOR = "#d9dce1"  # axis between venues when none of them trades


def _bounds(session, day: pd.Timestamp):
    """(open, close) of a (tz, open, close) session on `day` as naive LOCAL_TZ."""
    tz, open_time, close_time = session
    return tuple(pd.Timestamp(f"{day.date()} {t}", tz=tz).tz_convert(LOCAL_TZ).tz_localize(None)
                 for t in (open_time, close_time))


@cache.memoize(timeout=INTRADAY_TTL, response_filter=lambda result: not result.empty)
def _intraday_window(ticker: str) -> pd.Series:
    """Last 5 days of 15min closes in LOCAL_TZ (all sessions, unfiltered)."""
    try:
        return download_intraday_close(ticker, period="5d", interval="15m", tz=LOCAL_TZ)
    except Exception:
        return pd.Series(dtype=float)


def _venue_prices(ticker: str, fx: str | None) -> pd.Series:
    """Intraday prices in USD: listings in another currency are divided by the
    intraday FX quote (e.g. "JPY=X" = yen per dollar) at the same time."""
    s = _intraday_window(ticker).sort_index()
    if s.empty or not fx:
        return s
    rate = _intraday_window(fx).sort_index()
    if rate.empty:
        return pd.Series(dtype=float)
    joined = pd.merge_asof(s.rename("p").to_frame(), rate.rename("fx").to_frame(),
                           left_index=True, right_index=True, direction="backward")
    return (joined["p"] / joined["fx"]).dropna()


def _venue_windows(codes, day):
    """Per venue the part of its session it 'owns' on `day`: from its open
    until its close or the next venue's open, whichever comes first (London
    hands over to New York at the New York open)."""
    raw = [_bounds(VENUES[c]["session"], day) for c in codes]
    windows = []
    for k, (start, end) in enumerate(raw):
        if k + 1 < len(raw):
            end = min(end, raw[k + 1][0])
        windows.append((start, end, raw[k][1]))  # (own from, own to, real close)
    return windows


def _chained_intraday(item):
    """One trading day across several listings of the SAME index (item
    "venues": [(code, ticker, fx)], in time order, e.g. Tokyo -> London ->
    New York). The chain level moves with whichever venue owns the time:
    each venue re-anchors on its own last price and the chain level at that
    moment (level = anchor level * price / anchor price), so nothing is
    counted twice. When a venue opens while the previous one still trades
    (London -> New York), it continues seamlessly from the current level;
    after a break without trading (Tokyo -> London) its own opening move
    carries the news of the break. Reference = the chain level at the last
    price before the day (the previous New York close) = 100.

    Returns None without usable data (the card falls back to one listing)."""
    venues = item["venues"]
    prices = {code: _venue_prices(ticker, fx) for code, ticker, fx in venues}
    codes = [code for code, _, _ in venues if not prices[code].empty]
    if not codes or codes[-1] != venues[-1][0]:
        return None
    days = sorted(set().union(*(set(prices[c].index.normalize()) for c in codes)))
    observations = []
    for day in days:
        windows = _venue_windows(codes, day)
        for k, code in enumerate(codes):
            start, end, _ = windows[k]
            p = prices[code]
            part = p[(p.index >= start) & (p.index < end)]
            observations += [(t, k, code, float(v)) for t, v in part.items()]
    observations.sort()
    if not observations:
        return None

    level, anchors, points, previous = None, {}, {}, None
    for t, k, code, price in observations:
        if level is None:
            level = 1.0
        day = t.normalize()
        starts_session = previous is None or previous[2] != code
        overlap = False
        if starts_session and previous is not None and previous[1] < k:
            # previous venue (earlier in the day's order) still trading now?
            prev_close = _venue_windows(codes, day)[previous[1]][2]
            overlap = previous[0].normalize() == day and t < prev_close
        if code in anchors and not (starts_session and overlap):
            anchor_level, anchor_price = anchors[code]
            level = anchor_level * price / anchor_price
        anchors[code] = (level, price)
        points[t] = level
        previous = (t, k, code)
    chain = pd.Series(points).sort_index()

    today = pd.Timestamp.now(tz=LOCAL_TZ).tz_localize(None).normalize()
    shown = [d for d in chain.index.normalize().unique() if d <= today]
    if not shown:
        return None
    day = max(shown)
    before = chain[chain.index.normalize() < day]
    if before.empty:
        return None
    base = float(before.iloc[-1])
    day_chain = chain[chain.index.normalize() == day]

    # Axis: every venue's owned window in its colour, breaks without trading
    # in grey, ticks at every boundary, times only at the ends (no room).
    windows = _venue_windows(codes, day)
    segments, labels, ticks, cursor = [], [], [], None
    for k, code in enumerate(codes):
        start, end, _ = windows[k]
        if cursor is not None and start > cursor:
            segments.append((cursor, start, NO_TRADING_COLOR))
        segments.append((start, end, VENUES[code]["color"]))
        labels.append((start, end, code, VENUES[code]["color"]))
        if k:
            ticks.append((start, ""))
            if cursor is not None and start > cursor:
                ticks.append((cursor, ""))
        cursor = end
    first, last = windows[0][0], windows[-1][1]
    return {
        "series": 100 * day_chain / base,
        "reference": 100.0,
        "change": float(day_chain.iloc[-1] / base - 1),
        "session": (first, last, first.strftime("%H:%M"), last.strftime("%H:%M")),
        "segments": segments,
        "mid_ticks": ticks,
        "venues": labels,
    }


def _card_intraday(item):
    """Intraday data for an overview card: several venues chained where the
    item lists them, otherwise the class's own listing only (New York, or
    around the clock for crypto)."""
    if item.get("venues"):
        chained = _chained_intraday(item)
        if chained:
            return chained
    series = _intraday_series(item["ticker"])
    day = series.index[-1].normalize() if len(series) else pd.Timestamp.now().normalize()
    reference = _previous_close(item, day)
    session = _session_bounds(item, day) if len(series) else None
    single_venue = session is not None and item.get("session") == US_SESSION
    return {
        "series": series,
        "reference": reference,
        "change": _daily_change(item, series, reference),
        "session": session,
        "segments": [(session[0], session[1], VENUES["NY"]["color"])] if single_venue else None,
        "mid_ticks": None,
        "venues": [(session[0], session[1], "NY", VENUES["NY"]["color"])] if single_venue else None,
    }


def _data_stamp(series: pd.Series) -> str:
    if series.empty:
        return "Stand: –"
    return f"Stand: {series.index[-1].strftime('%d.%m.%Y %H:%M')}"


def _filtered(series: pd.Series, years) -> pd.Series:
    s = series.dropna().sort_index()
    if s.empty:
        return s
    if isinstance(years, dict):
        start = pd.to_datetime(years.get("start"), errors="coerce")
        end = pd.to_datetime(years.get("end"), errors="coerce")
        if pd.isna(start) or pd.isna(end):
            return s
        return s[(s.index >= start) & (s.index <= end)]
    if years == "max":
        return s
    cutoff = pd.Timestamp.now().normalize() - _period_offset(years)
    return s[s.index >= cutoff]


# Preset values of RANGE_OPTIONS: "1w"/"1m"/"6m" = weeks/months, plain
# numbers ("1", "3", ...) = years.
_SHORT_PERIODS = {"1w": pd.DateOffset(weeks=1), "1m": pd.DateOffset(months=1), "6m": pd.DateOffset(months=6)}


def _period_offset(period) -> pd.DateOffset:
    return _SHORT_PERIODS.get(period) or pd.DateOffset(years=int(period))


# Slots in their validated order, one per asset class (ASSET_CLASSES order).
ASSET_CLASS_COLORS = PALETTE[:8]


def _comparison_series() -> dict:
    """Full daily history per asset class, on one shared trading calendar for
    the comparison charts: 24/7 series (crypto, session None) keep only the
    days the exchange-traded classes trade - no weekends or exchange holidays -
    so every line starts and ends on the same dates. Single-asset charts (e.g.
    the Krypto page) still show every calendar day."""
    raw = {item["key"]: _asset_class_series(item["ticker"]).dropna().sort_index() for item in ASSET_CLASSES}
    calendar = pd.DatetimeIndex([])
    for item in ASSET_CLASSES:
        if item.get("session") is not None:
            calendar = calendar.union(raw[item["key"]].index)
    if len(calendar):
        for item in ASSET_CLASSES:
            if item.get("session") is None:
                s = raw[item["key"]]
                raw[item["key"]] = s[s.index.isin(calendar)]
    return raw


def _overview_spec(years, drawdown=False, reset_range=None, chart_id="overview-chart"):
    selected_start, selected_end = _period_bounds(years)
    base_period = reset_range or {"start": selected_start, "end": selected_end}
    aligned = _comparison_series()
    series_list = []
    for i, item in enumerate(ASSET_CLASSES):
        # Always load full history so users can freely zoom/scroll out past the
        # initially selected period (1J/3J/.../custom) without hitting a wall
        # of missing data - only the *visible* range is limited to the
        # selection below.
        s = aligned[item["key"]]
        if len(s) < 2:
            continue
        series_list.append(tv_series(
            item["label"], s, ASSET_CLASS_COLORS[i % len(ASSET_CLASS_COLORS)],
            show_last_value=False,
        ))
    spec = tv_spec(
        series_list,
        height=480,
        log_scale=False,
        value_format="percent",
        show_legend=True,
        legend_position="bottom",
    )
    spec["ariaLabel"] = "Drawdown der Anlageklassen" if drawdown else "Kumulierte Rendite der Anlageklassen"
    spec["rangeStoreId"] = f"{chart_id}-zoom-range"
    spec["resetRange"] = base_period
    spec["visibleRange"] = {"start": selected_start, "end": selected_end}
    spec["visibleTransform"] = "drawdown" if drawdown else "return"
    # Each chart gets its own sync group (its id) so it never syncs with the
    # other chart - they're independent now, but tv-chart.js still uses a
    # truthy syncGroup to size-reserve the left price scale consistently.
    spec["syncGroup"] = chart_id
    spec["syncKey"] = chart_id
    spec["leftAxis"] = True
    spec["rightValueLabels"] = True
    return spec


def _snap_to_trading_days(start, end):
    """Start -> first trading day on/after it, end -> last trading day on/before
    it (shared calendar of the comparison charts), so picked weekends/holidays
    resolve to dates that actually have prices."""
    calendar = pd.DatetimeIndex([])
    for s in _comparison_series().values():
        calendar = calendar.union(s.index)
    if not len(calendar):
        return start, end
    start_pos = min(calendar.searchsorted(start, side="left"), len(calendar) - 1)
    end_pos = max(calendar.searchsorted(end, side="right") - 1, 0)
    return calendar[start_pos], calendar[end_pos]


def _period_bounds(period):
    period = period or "5"
    if isinstance(period, dict):
        return period.get("start"), period.get("end")
    available = [s for s in _comparison_series().values() if not s.empty]
    if not available:
        return None, None
    end_timestamp = max(s.index[-1] for s in available).normalize()
    if period == "max":
        start_timestamp = min(s.index[0] for s in available)
    else:
        start_timestamp = end_timestamp - _period_offset(period)
    start_timestamp, end_timestamp = _snap_to_trading_days(start_timestamp, end_timestamp)
    return start_timestamp.date().isoformat(), end_timestamp.date().isoformat()


def _display_date(value):
    if not value:
        return "-"
    return pd.to_datetime(value).strftime("%d.%m.%Y")


def _period_descriptions(period):
    return (
        "Total Return (ETF-Kurse in USD, Ausschüttungen reinvestiert, nach Fondskosten, "
        "vor Steuern des Anlegers)",
        "Abstand zum bisherigen Höchststand (Total Return, 0 % = neues Hoch)",
        "Kennzahlen seit Auflage des jeweiligen ETFs (Total Return in USD, "
        "annualisiert mit 252 Handelstagen, Krypto 365)",
    )


def _previous_close(item, day):
    """Last daily close before `day` (the intraday session shown on the card).
    Taken by date, not as "second to last value": the daily series is cached
    for hours and may or may not already contain today's bar."""
    series = _asset_class_series(item["ticker"]).dropna().sort_index()
    before = series[series.index.normalize() < day]
    return float(before.iloc[-1]) if len(before) else None


def _daily_change(item, intraday, previous_close):
    """Change of the card's session: latest intraday price vs. the previous
    close, so it matches the sparkline and the "Stand" time. Without intraday
    data, falls back to the last two daily closes."""
    if len(intraday) and previous_close:
        return float(intraday.iloc[-1] / previous_close - 1)
    series = _asset_class_series(item["ticker"]).dropna().sort_index()
    if len(series) < 2:
        return None
    return float(series.iloc[-1] / series.iloc[-2] - 1)


def _stat_card(item):
    intraday = _card_intraday(item)
    series, previous_close, daily = intraday["series"], intraday["reference"], intraday["change"]
    performance_text = "–" if daily is None else f"{daily:+.2%}".replace(".", ",")
    direction = "neutral" if daily is None else ("positive" if daily >= 0 else "negative")
    chart_color = "#16865c" if direction == "positive" else "#c54848" if direction == "negative" else "#7a808b"
    session = intraday["session"]

    card = dmc.Paper(
        [
            html.Div([
                # Name highlighted edge to edge in the heading-box colour.
                html.Div(
                    dmc.Text(item["label"], className="overview-selector-title", fw=700),
                    className="overview-asset-band",
                ),
                dmc.Text(item["sub"], className="overview-proxy"),
            ], className="overview-selector-textblock"),
            html.Div([
                recharts_sparkline(
                    f"overview-sparkline-{item['key']}", series, chart_color, height=68,
                    reference_value=previous_close, session=session,
                    segments=intraday["segments"], mid_ticks=intraday["mid_ticks"],
                    venues=intraday["venues"],
                ) if len(series) >= 1 else html.Div(className="overview-sparkline-empty"),
                dmc.Text(performance_text, className="overview-selector-performance"),
            ], className="overview-selector-performance-row"),
            dmc.Text(_data_stamp(series), className="overview-data-stamp"),
        ],
        p="md", radius=2, withBorder=False,
        # Display only: the cards don't link anywhere (pages are reached via
        # the Märkte menu).
        className=f"stat-card overview-selector-card overview-selector-{direction}",
    )
    return card


ANNUAL_METRICS = [
    {"label": "CAGR", "value": "cagr"},
    {"label": "Standard Deviation", "value": "volatility"},
    {"label": "Downside Deviation", "value": "downside_deviation"},
    {"label": "Max. Drawdown", "value": "drawdown"},
    {"label": "Sharpe Ratio", "value": "sharpe"},
    {"label": "Sortino Ratio", "value": "sortino"},
    {"label": "Calmar Ratio", "value": "calmar"},
]


def _statistics(s, item):
    returns = s.pct_change(fill_method=None).dropna()
    periods = 365 if item["ticker"] == "BTC-USD" else 252
    vol = float(returns.std(ddof=1) * math.sqrt(periods))
    annual_mean = float(returns.mean() * periods)
    downside = float(returns.clip(upper=0).pow(2).mean() ** 0.5 * math.sqrt(periods))
    cg, dd = cagr(s), max_drawdown(s)
    return {
        "return": float(s.iloc[-1] / s.iloc[0] - 1),
        "cagr": cg, "volatility": vol, "downside_deviation": downside, "drawdown": dd,
        "sharpe": annual_mean / vol if vol > 0 else float("nan"),
        "sortino": annual_mean / downside if downside > 0 else float("nan"),
        "calmar": cg / abs(dd) if dd < 0 else float("nan"),
    }


def _metrics_table(years):
    columns = {"CAGR": "cagr", "Standard Deviation": "volatility",
               "Downside Deviation": "downside_deviation",
               "Max. Drawdown": "drawdown", "Sharpe Ratio": "sharpe",
               "Sortino Ratio": "sortino", "Calmar Ratio": "calmar"}
    rows = {}
    for item in ASSET_CLASSES:
        s = _filtered(_asset_class_series(item["ticker"]), years)
        if len(s) >= 2:
            stats = _statistics(s, item)
            rows[item["label"]] = {label: stats[key] for label, key in columns.items()}
    table = _colored_table(pd.DataFrame.from_dict(rows, orient="index"))
    if hasattr(table, "columnDefs"):
        for col in table.columnDefs[1:]:
            kind = "percent" if columns[col["field"]] in {
                "cagr", "volatility", "downside_deviation", "drawdown"
            } else "ratio"
            col["valueFormatter"] = ag_value_formatter(kind)
    return table


def _annual_table(metric, years="max"):
    if metric not in {option["value"] for option in ANNUAL_METRICS}:
        metric = "cagr"
    rows = {}
    for item in ASSET_CLASSES:
        s = _filtered(_asset_class_series(item["ticker"]), years).sort_index()
        values = {}
        for year in sorted(set(s.index.year)):
            part = s[s.index.year == year]
            # Previous year's closing value includes the first trading day's return.
            previous = s[s.index < part.index[0]].tail(1)
            window = pd.concat([previous, part])
            if len(window) >= 2:
                values[str(year)] = _statistics(window, item)[metric]
        rows[item["label"]] = values
    df = pd.DataFrame.from_dict(rows, orient="index")
    df = df.reindex(index=[item["label"] for item in ASSET_CLASSES])
    df = df.reindex(columns=sorted(df.columns, reverse=True))
    table = _colored_table(df)
    if hasattr(table, "columnDefs"):
        for col in table.columnDefs[1:]:
            col["valueFormatter"] = ag_value_formatter(
                "percent" if metric in {
                    "cagr", "volatility", "downside_deviation", "drawdown"
                } else "ratio"
            )
            col["width"] = 110
    return table


ROW_LABEL_WIDTH = 200  # px, first table column - keep in sync with .overview-annual-select-in-grid


def _colored_table(df):
    if df.empty:
        return dmc.Text("Keine Daten vorhanden.")
    table = ag_heat_table(df)
    for row in table.rowData:
        for col in df.columns:
            row.pop(f"__bg_{col}", None)
            row.pop(f"__fg_{col}", None)
    for col in table.columnDefs[1:]:
        col.pop("cellStyle", None)
    table.columnDefs[0].update({
        # Fixed width (no flex): the Kalenderjahre metric select is laid over
        # this column's header cell and needs a known width.
        # Pinned so it (and the select over it) stays put when the table
        # scrolls sideways.
        "headerName": "", "width": ROW_LABEL_WIDTH, "minWidth": ROW_LABEL_WIDTH, "flex": 0,
        "pinned": "left",
        "cellStyle": {"fontWeight": "700", "color": "#16181d"},
    })
    table.defaultColDef = {**table.defaultColDef, "minWidth": 115, "flex": 1, "wrapHeaderText": True,
                          "autoHeaderHeight": False, "sortable": True}
    table.dashGridOptions.update({"rowHeight": 42, "headerHeight": 60, "autoSizeStrategy": None})
    return table


def _card(title, subtitle, children):
    return html.Div([
        html.Div([
            card_header(title, html.Div()),
            dmc.Text(subtitle, className="overview-section-subtitle", size="xs", c="dimmed"),
        ], className="overview-heading-box"),
        *children,
    ], className="section-card")


def _chart_section(chart_id, title, drawdown, default_period="5"):
    """A single chart card: heading, its own period controls (date range +
    1J/3J/.../Max), and the chart itself - fully independent from any other
    chart's period selection."""
    initial_start, initial_end = _period_bounds(default_period)
    return_description, drawdown_description, _ = _period_descriptions(default_period)
    description = drawdown_description if drawdown else return_description
    return html.Div([
        html.Div([
            card_header(title, html.Div()),
            dmc.Text(description, id=f"{chart_id}-description",
                     className="overview-section-subtitle", size="xs", c="dimmed"),
        ], className="overview-heading-box"),
        html.Div([
            html.Div([
                # Two single pickers instead of dcc.DatePickerRange: the range
                # calendar always treats the first clicked day as the *start*,
                # even when the end field was clicked - confusing when only the
                # end date should change.
                html.Div([
                    html.Div([
                        dcc.DatePickerSingle(
                            id=f"{chart_id}-start-date", date=initial_start,
                            display_format="DD.MM.YYYY", first_day_of_week=1,
                            placeholder="Startdatum", clearable=False,
                        ),
                        html.Span(DashIconify(icon="tabler:arrow-right", width=12),
                                  className="dash-datepicker-range-arrow"),
                        dcc.DatePickerSingle(
                            id=f"{chart_id}-end-date", date=initial_end,
                            display_format="DD.MM.YYYY", first_day_of_week=1,
                            placeholder="Enddatum", clearable=False,
                            className="date-picker-latest",  # "Aktuelles Datum" button, assets/datepicker-latest.js
                        ),
                    ], className="overview-date-range"),
                ], className="overview-date-control"),
            ], className="overview-control-group"),
            html.Div([
                dmc.SegmentedControl(
                    id=f"{chart_id}-range", data=RANGE_OPTIONS, value=default_period,
                    className="overview-range-selector",
                    **{"aria-label": "Vordefinierten Zeitraum auswählen"},
                ),
            ], className="overview-control-group overview-preset-control"),
        ], className="overview-controls"),
        dcc.Store(id=f"{chart_id}-zoom-range"),
        dcc.Store(id=f"{chart_id}-zoom-base", data={"start": initial_start, "end": initial_end}),
        tv_chart(chart_id, _overview_spec(default_period, drawdown=drawdown, chart_id=chart_id)),
    ], className="section-card")


def layout(params=None):
    with ThreadPoolExecutor(max_workers=8) as pool:
        list(pool.map(_asset_class_series, [item["ticker"] for item in ASSET_CLASSES]))
    metrics_description = _period_descriptions("max")[2]
    return html.Div([
        html.Div([
            html.Div(
                [_stat_card(item) for item in ASSET_CLASSES],
                className="overview-asset-grid",
            ),
        ], className="overview-asset-panel"),
        html.Div([
            _chart_section("overview-chart", "Rendite", False, default_period="1"),
            _chart_section("overview-drawdown", "Drawdown", True, default_period="max"),
        ], className="overview-two-columns"),
        html.Div([
            _card("Risiko-Rendite-Kennzahlen", metrics_description, [
                html.Div(children=_metrics_table("max")),
            ]),
            html.Div([
                html.Div([
                    card_header("Kennzahlen nach Kalenderjahren", html.Div()),
                    dmc.Text("Werte je Kalenderjahr (Auflagejahr und laufendes Jahr unvollständig)",
                             className="overview-section-subtitle", size="xs", c="dimmed"),
                ], className="overview-heading-box"),
                html.Div([
                    # Sits in the table's empty top-left header cell (first
                    # column has a fixed width, see _colored_table).
                    dmc.Select(
                        id="overview-annual-metric", data=ANNUAL_METRICS, value="cagr",
                        allowDeselect=False,
                        className="overview-annual-select overview-annual-select-in-grid",
                    ),
                    html.Div(id="overview-annual", children=_annual_table("cagr", "max")),
                ], className="overview-annual-table-wrap"),
            ], className="section-card"),
        ], className="overview-two-columns"),
    ], className="markets-overview")


def _register_chart_callback(app, chart_id, drawdown):
    """Wires one chart's own period controls (date range + preset buttons) to
    its own chart data - fully independent of any other chart on the page."""
    start_id, end_id = f"{chart_id}-start-date", f"{chart_id}-end-date"
    range_id = f"{chart_id}-range"
    zoom_range_id = f"{chart_id}-zoom-range"
    zoom_base_id = f"{chart_id}-zoom-base"
    description_id = f"{chart_id}-description"

    @app.callback(
        Output(start_id, "date"),
        Output(end_id, "date"),
        Output(range_id, "value"),
        Output({"type": "tv-chart-data", "index": chart_id}, "data"),
        Output(description_id, "children"),
        Output(zoom_base_id, "data"),
        Input(zoom_range_id, "data"),
        Input(range_id, "value"),
        Input(start_id, "date"),
        Input(end_id, "date"),
        State(zoom_base_id, "data"),
    )
    def update_chart(zoom_range, years, custom_start, custom_end, zoom_base):
        trigger = ctx.triggered_id
        from_picker = trigger in (start_id, end_id)
        base_output = no_update
        if trigger == zoom_range_id:
            if not isinstance(zoom_range, dict):
                raise PreventUpdate
            start, end = zoom_range.get("start"), zoom_range.get("end")
            range_output = None
        elif from_picker or not years:
            start, end = custom_start, custom_end
            range_output = None
        else:
            start, end = _period_bounds(years)
            range_output = years

        start_date = pd.to_datetime(start, errors="coerce")
        end_date = pd.to_datetime(end, errors="coerce")
        if not pd.isna(start_date) and not pd.isna(end_date):
            start_date, end_date = _snap_to_trading_days(start_date, end_date)
        if pd.isna(start_date) or pd.isna(end_date) or start_date >= end_date:
            if from_picker and isinstance(zoom_base, dict):
                # e.g. a start picked after the end: snap both pickers back to
                # the last valid period instead of showing dates that don't apply.
                return (zoom_base.get("start"), zoom_base.get("end"),
                        no_update, no_update, no_update, no_update)
            raise PreventUpdate
        selected_period = {"start": start_date.date().isoformat(), "end": end_date.date().isoformat()}
        if from_picker and zoom_base == selected_period:
            # The preset-button branch below writes its computed dates back
            # into these same date pickers, which are also this callback's
            # Inputs - that self-triggers a second, redundant firing from a
            # picker but with an identical period.
            # Without this guard that second firing forces the TradingView
            # chart to fully tear down and rebuild (see tv-chart.js), which
            # briefly repaints raw/untransformed series before the %-return
            # transform reapplies - a visible flash of "wrong" data.
            # A picked non-trading day can snap onto the current period too
            # (e.g. the Saturday before the current Monday start): then only
            # the pickers need correcting, the chart stays as is.
            picked = tuple(pd.to_datetime(d, errors="coerce") for d in (custom_start, custom_end))
            if picked != (start_date, end_date):
                return (selected_period["start"], selected_period["end"],
                        no_update, no_update, no_update, no_update)
            raise PreventUpdate
        if trigger != zoom_range_id:
            zoom_base = selected_period
            base_output = zoom_base
        zoom_base = zoom_base or selected_period
        return_description, drawdown_description, _ = _period_descriptions(selected_period)
        description = drawdown_description if drawdown else return_description
        spec = _overview_spec(selected_period, drawdown=drawdown, reset_range=zoom_base, chart_id=chart_id)
        return (selected_period["start"], selected_period["end"], range_output, spec,
                description, base_output)


def register_callbacks(app):
    _register_chart_callback(app, "overview-chart", drawdown=False)
    _register_chart_callback(app, "overview-drawdown", drawdown=True)

    @app.callback(
        Output("overview-annual", "children"),
        Input("overview-annual-metric", "value"),
    )
    def update_annual(metric):
        return _annual_table(metric, "max")
