"""'Mein Portfolio' (third section in the top bar). Placeholder until the
portfolio features are defined - same card/heading-box styles as the market
overview."""
from __future__ import annotations

import dash_mantine_components as dmc
from dash import html

from src.theme import card_header


def layout(params=None):
    return html.Div([
        html.Div([
            html.Div([
                card_header("Mein Portfolio", html.Div()),
                dmc.Text("Eigene Positionen, Aufteilung und Wertentwicklung (in Vorbereitung)",
                         className="overview-section-subtitle", size="xs", c="dimmed"),
            ], className="overview-heading-box"),
        ], className="section-card"),
    ], className="markets-overview")
